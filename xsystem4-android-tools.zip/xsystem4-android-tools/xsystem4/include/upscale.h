/* Copyright (C) 2026 xsystem4-android contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://gnu.org/licenses/>.
 */

#ifndef SYSTEM4_UPSCALE_H
#define SYSTEM4_UPSCALE_H

#include <stdbool.h>
#include <stddef.h>
#include "gfx/gl.h"

struct texture;

/*
 * Optional spatial upscaling of the game surface to the screen.
 *
 * The game always renders at its fixed logical resolution (main_surface).
 * When an upscaler is enabled, gfx_swap() first runs it on that surface and
 * then stretches the result to the window, instead of stretching the raw
 * surface with plain bilinear filtering.
 */

enum upscale_mode {
	UPSCALE_OFF  = 0,
	UPSCALE_FSR  = 1,  // AMD FidelityFX Super Resolution 1.0 (EASU + RCAS)
	UPSCALE_SGSR = 2,  // Snapdragon Game Super Resolution 1.0
	NR_UPSCALE_MODES
};

enum upscale_quality {
	UPSCALE_ULTRA_QUALITY = 0,
	UPSCALE_QUALITY       = 1,
	UPSCALE_BALANCED      = 2,
	UPSCALE_PERFORMANCE   = 3,
	NR_UPSCALE_QUALITIES
};

// Thread-safe; may be called from any thread (e.g. the Android UI thread).
void upscale_set(int mode, int quality);
void upscale_get(int *mode, int *quality);

bool upscale_parse_mode(const char *s, int *mode);
bool upscale_parse_quality(const char *s, int *quality);

/*
 * Run the selected upscaler on SRC for a screen viewport of vp_w x vp_h.
 * Returns the handle of a texture holding the result (to be drawn like the
 * source), or 0 if upscaling is off, not applicable, or unavailable; in that
 * case the caller draws SRC as usual. Must be called on the GL thread.
 */
GLuint upscale_process(struct texture *src, int vp_w, int vp_h);

// Human readable description of what the upscaler is doing (UTF-8).
void upscale_status(char *buf, size_t size);

#endif /* SYSTEM4_UPSCALE_H */
