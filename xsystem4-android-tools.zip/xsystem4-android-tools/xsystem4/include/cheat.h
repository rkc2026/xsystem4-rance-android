/* Copyright (C) 2026 xsystem4-android contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://gnu.org/licenses/>.
 */

#ifndef SYSTEM4_CHEAT_H
#define SYSTEM4_CHEAT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/*
 * A small "cheat engine" for the game's VM: it can search the VM's variables
 * (globals, struct members, array elements) for values, change them, and
 * freeze them.
 *
 * Threading: the VM runs on the game thread. The functions in the first group
 * are called by the game thread; they hand the VM over at safe points (while
 * pumping events or sleeping) so that the functions in the second group,
 * which are called from other threads (the Android UI thread), can inspect
 * and modify VM memory without racing against the interpreter.
 */

/* Game thread */
void cheat_init(void);           // called once when the VM starts
void cheat_vm_reset(void);       // VM state was re-initialized; drop all addresses
void cheat_safepoint_begin(void);
void cheat_safepoint_end(void);

/* Other threads */
bool cheat_is_ready(void);  // has the VM started?

enum cheat_result {
	CHEAT_OK        =  0,
	CHEAT_BUSY      = -1,  // the VM did not reach a safe point in time
	CHEAT_NOT_READY = -2,  // the VM has not started yet
	CHEAT_STALE     = -3,  // the variable no longer exists
	CHEAT_BAD_VALUE = -4,  // the value could not be parsed
	CHEAT_BAD_TYPE  = -5,
	CHEAT_FULL      = -6,
	CHEAT_NO_SCAN   = -7,  // no scan in progress
	CHEAT_TRUNCATED = -8,  // (informational) result list was cut short
};

enum cheat_kind {
	CHEAT_INT   = 0,
	CHEAT_FLOAT = 1,
	CHEAT_BOOL  = 2,
};

enum cheat_scan_type {
	CHEAT_SCAN_INT   = 0,
	CHEAT_SCAN_FLOAT = 1,
};

enum cheat_cmp {
	CHEAT_CMP_EXACT     = 0,
	CHEAT_CMP_UNKNOWN   = 1,  // first scan only: keep every value
	CHEAT_CMP_GREATER   = 2,
	CHEAT_CMP_LESS      = 3,
	CHEAT_CMP_CHANGED   = 4,  // next scan only
	CHEAT_CMP_UNCHANGED = 5,
	CHEAT_CMP_INCREASED = 6,
	CHEAT_CMP_DECREASED = 7,
};

#define CHEAT_SCAN_INCLUDE_LOCALS 1

// Returns the number of matches (>= 0) or a negative cheat_result.
int cheat_scan_first(int type, int cmp, const char *value, int flags);
int cheat_scan_next(int cmp, const char *value);
void cheat_scan_reset(void);
bool cheat_scan_truncated(void);

// The following fill BUF with tab separated lines
//   slot, index, seq, kind, frozen, value, label
// and return the number of bytes used, or a negative cheat_result.
int cheat_scan_results(int offset, int limit, char *buf, size_t size);
int cheat_browse(const char *filter, int limit, char *buf, size_t size);
int cheat_frozen_list(char *buf, size_t size);

int cheat_write(int32_t slot, int32_t index, uint32_t seq, int kind, const char *value);
int cheat_freeze(int32_t slot, int32_t index, uint32_t seq, int kind, const char *value,
		 const char *label, bool enable);

#endif /* SYSTEM4_CHEAT_H */
