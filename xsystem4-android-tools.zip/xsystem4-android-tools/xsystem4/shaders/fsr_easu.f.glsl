/* AMD FidelityFX Super Resolution 1.0 -- EASU (Edge Adaptive Spatial Upsampling)
 *
 * GLSL ES 3.00 port of the float (non-packed) EASU path from ffx_fsr1.h
 * (FidelityFX-FSR v1.20210629).
 *
 *   Copyright (c) 2021 Advanced Micro Devices, Inc. All rights reserved.
 *   Distributed under the MIT License, see licenses/FidelityFX-FSR.txt.
 *
 * Changes from the reference implementation:
 *  - textureGather() is not available in ES 3.00, so the 12 taps are read
 *    with texelFetch() (clamped to the texture edge). The gather lane
 *    layout of the reference has been resolved to explicit tap offsets.
 *  - Where the reference leaves division by zero to the hardware, the
 *    argument is guarded. On GLSL ES 3.00 (and GLSL >= 3.30) the reference's
 *    bit-trick reciprocal / reciprocal-sqrt approximations are used, so the
 *    output is identical to the reference; older desktop GLSL (1.40, which
 *    lacks floatBitsToUint) falls back to exact guarded versions.
 */

uniform highp sampler2D tex;
uniform vec2 u_src_size;   // size of the input texture in texels
uniform vec2 u_out_size;   // size of the render target in pixels

in vec2 tex_coord;
out vec4 frag_color;

// APrxLoRcpF1() / APrxLoRsqF1() from ffx_a.h.
#if __VERSION__ >= 300
float prx_rcp(float a) { return uintBitsToFloat(0x7ef07ebbu - floatBitsToUint(a)); }
float prx_rsq(float a) { return uintBitsToFloat(0x5f347d74u - (floatBitsToUint(a) >> 1u)); }
#else
float prx_rcp(float a) { return 1.0 / max(a, 1.0e-10); }
float prx_rsq(float a) { return inversesqrt(max(a, 1.0e-10)); }
#endif

vec3 fetch_rgb(ivec2 p)
{
        ivec2 hi = ivec2(u_src_size) - ivec2(1);
        return texelFetch(tex, clamp(p, ivec2(0), hi), 0).rgb;
}

// Luma times 2, in 2 FMA/MAD.
float luma2(vec3 c)
{
        return c.b * 0.5 + (c.r * 0.5 + c.g);
}

// Filtering for a given tap for the scalar.
void easu_tap(inout vec3 aC, inout float aW, vec2 off, vec2 dir, vec2 len,
              float lob, float clp, vec3 c)
{
        // Rotate offset by direction.
        vec2 v;
        v.x = (off.x * ( dir.x)) + (off.y * dir.y);
        v.y = (off.x * (-dir.y)) + (off.y * dir.x);
        // Anisotropy.
        v *= len;
        // Compute distance^2.
        float d2 = v.x * v.x + v.y * v.y;
        // Limit to the window as at corner, 2 taps can easily be outside.
        d2 = min(d2, clp);
        // Approximation of lanczos2 without sin() or rcp(), or sqrt() to get x.
        float wB = 2.0 / 5.0 * d2 - 1.0;
        float wA = lob * d2 - 1.0;
        wB *= wB;
        wA *= wA;
        wB = 25.0 / 16.0 * wB - (25.0 / 16.0 - 1.0);
        float w = wB * wA;
        // Do weighted average.
        aC += c * w;
        aW += w;
}

// Accumulate direction and length.
void easu_set(inout vec2 dir, inout float len, vec2 pp,
              bool biS, bool biT, bool biU, bool biV,
              float lA, float lB, float lC, float lD, float lE)
{
        // Compute bilinear weight.
        //  s t
        //  u v
        float w = 0.0;
        if (biS) w = (1.0 - pp.x) * (1.0 - pp.y);
        if (biT) w =        pp.x  * (1.0 - pp.y);
        if (biU) w = (1.0 - pp.x) *        pp.y;
        if (biV) w =        pp.x  *        pp.y;
        // Direction is the '+' diff.
        //    a
        //  b c d
        //    e
        // Then takes magnitude from abs average of both sides of 'c'.
        float dc = lD - lC;
        float cb = lC - lB;
        float lenX = max(abs(dc), abs(cb));
        lenX = prx_rcp(lenX);
        float dirX = lD - lB;
        dir.x += dirX * w;
        lenX = clamp(abs(dirX) * lenX, 0.0, 1.0);
        lenX *= lenX;
        len += lenX * w;
        // Repeat for the y axis.
        float ec = lE - lC;
        float ca = lC - lA;
        float lenY = max(abs(ec), abs(ca));
        lenY = prx_rcp(lenY);
        float dirY = lE - lA;
        dir.y += dirY * w;
        lenY = clamp(abs(dirY) * lenY, 0.0, 1.0);
        lenY *= lenY;
        len += lenY * w;
}

void main()
{
        // Integer pixel position in the output.
        ivec2 ip = ivec2(floor(tex_coord * u_out_size));

        // Get position of 'f'.
        vec2 scale = u_src_size / u_out_size;
        vec2 pp = vec2(ip) * scale + (0.5 * scale - 0.5);
        vec2 fp = floor(pp);
        pp -= fp;
        ivec2 f0 = ivec2(fp);

        // 12-tap kernel.
        //    b c
        //  e f g h
        //  i j k l
        //    n o
        vec3 cB = fetch_rgb(f0 + ivec2( 0, -1));
        vec3 cC = fetch_rgb(f0 + ivec2( 1, -1));
        vec3 cE = fetch_rgb(f0 + ivec2(-1,  0));
        vec3 cF = fetch_rgb(f0 + ivec2( 0,  0));
        vec3 cG = fetch_rgb(f0 + ivec2( 1,  0));
        vec3 cH = fetch_rgb(f0 + ivec2( 2,  0));
        vec3 cI = fetch_rgb(f0 + ivec2(-1,  1));
        vec3 cJ = fetch_rgb(f0 + ivec2( 0,  1));
        vec3 cK = fetch_rgb(f0 + ivec2( 1,  1));
        vec3 cL = fetch_rgb(f0 + ivec2( 2,  1));
        vec3 cN = fetch_rgb(f0 + ivec2( 0,  2));
        vec3 cO = fetch_rgb(f0 + ivec2( 1,  2));

        float bL = luma2(cB), cLm = luma2(cC), eL = luma2(cE), fL = luma2(cF);
        float gL = luma2(cG), hL = luma2(cH), iL = luma2(cI), jL = luma2(cJ);
        float kL = luma2(cK), lL = luma2(cL), nL = luma2(cN), oL = luma2(cO);

        // Accumulate for bilinear interpolation.
        vec2 dir = vec2(0.0);
        float len = 0.0;
        easu_set(dir, len, pp, true,  false, false, false, bL,  eL, fL, gL, jL);
        easu_set(dir, len, pp, false, true,  false, false, cLm, fL, gL, hL, kL);
        easu_set(dir, len, pp, false, false, true,  false, fL,  iL, jL, kL, nL);
        easu_set(dir, len, pp, false, false, false, true,  gL,  jL, kL, lL, oL);

        // Normalize, and cleanup close to zero.
        vec2 dir2 = dir * dir;
        float dirR = dir2.x + dir2.y;
        bool zro = dirR < (1.0 / 32768.0);
        dirR = prx_rsq(dirR);
        dirR = zro ? 1.0 : dirR;
        dir.x = zro ? 1.0 : dir.x;
        dir *= vec2(dirR);

        // Transform from {0 to 2} to {0 to 1} range, and shape with square.
        len = len * 0.5;
        len *= len;

        // Stretch kernel {1.0 vert|horz, to sqrt(2.0) on diagonal}.
        float stretch = (dir.x * dir.x + dir.y * dir.y)
                      * prx_rcp(max(abs(dir.x), abs(dir.y)));

        // Anisotropic length after rotation,
        //  x := 1.0 lerp to 'stretch' on edges
        //  y := 1.0 lerp to 2x on edges
        vec2 len2 = vec2(1.0 + (stretch - 1.0) * len, 1.0 + (-0.5) * len);

        // Based on the amount of 'edge', the window shifts from
        // +/-{sqrt(2.0) to slightly beyond 2.0}.
        float lob = 0.5 + ((1.0 / 4.0 - 0.04) - 0.5) * len;

        // Set distance^2 clipping point to the end of the adjustable window.
        float clp = prx_rcp(lob);

        // Accumulation mixed with min/max of 4 nearest (f, g, j, k).
        vec3 min4 = min(min(min(cF, cG), cJ), cK);
        vec3 max4 = max(max(max(cF, cG), cJ), cK);

        // Accumulation.
        vec3 aC = vec3(0.0);
        float aW = 0.0;
        easu_tap(aC, aW, vec2( 0.0, -1.0) - pp, dir, len2, lob, clp, cB);
        easu_tap(aC, aW, vec2( 1.0, -1.0) - pp, dir, len2, lob, clp, cC);
        easu_tap(aC, aW, vec2(-1.0,  1.0) - pp, dir, len2, lob, clp, cI);
        easu_tap(aC, aW, vec2( 0.0,  1.0) - pp, dir, len2, lob, clp, cJ);
        easu_tap(aC, aW, vec2( 0.0,  0.0) - pp, dir, len2, lob, clp, cF);
        easu_tap(aC, aW, vec2(-1.0,  0.0) - pp, dir, len2, lob, clp, cE);
        easu_tap(aC, aW, vec2( 1.0,  1.0) - pp, dir, len2, lob, clp, cK);
        easu_tap(aC, aW, vec2( 2.0,  1.0) - pp, dir, len2, lob, clp, cL);
        easu_tap(aC, aW, vec2( 2.0,  0.0) - pp, dir, len2, lob, clp, cH);
        easu_tap(aC, aW, vec2( 1.0,  0.0) - pp, dir, len2, lob, clp, cG);
        easu_tap(aC, aW, vec2( 1.0,  2.0) - pp, dir, len2, lob, clp, cO);
        easu_tap(aC, aW, vec2( 0.0,  2.0) - pp, dir, len2, lob, clp, cN);

        // Normalize and dering.
        vec3 pix = min(max4, max(min4, aC * (1.0 / aW)));
        frag_color = vec4(pix, 1.0);
}
