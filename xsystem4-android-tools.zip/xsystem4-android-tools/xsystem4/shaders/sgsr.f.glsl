/* Snapdragon(TM) Game Super Resolution 1.0 (SGSR) -- single pass upscaler
 *
 * Port of sgsr1_shader_mobile.frag from
 * https://github.com/SnapdragonGameStudios/snapdragon-gsr
 *
 *   Copyright (c) 2025, Qualcomm Innovation Center, Inc. All rights reserved.
 *   SPDX-License-Identifier: BSD-3-Clause
 *   See licenses/SnapdragonGSR.txt.
 *
 * Changes from the original:
 *  - Operation mode 1 (RGBA, green channel as the edge signal) is hard-wired,
 *    since the game surface has no luma channel.
 *  - textureGather() is not available in GLSL ES 3.00; it is emulated with
 *    texelFetch() (clamped to the texture edge), and the base colour is a
 *    manual bilinear fetch, so the result does not depend on the sampler's
 *    filter / wrap state.
 *  - Edge threshold and edge sharpness are uniforms (quality modes).
 */

uniform highp sampler2D tex;
uniform vec2 u_src_size;          // size of the input texture in texels
uniform vec2 u_out_size;          // size of the render target in pixels
uniform float u_edge_sharpness;   // [1.0, 2.0], reference default 2.0
uniform float u_edge_threshold;   // reference default 8.0/255.0

in vec2 tex_coord;
out vec4 frag_color;

const int MODE = 1;               // channel used as the edge signal (G)

vec4 fetch4(ivec2 p)
{
        ivec2 hi = ivec2(u_src_size) - ivec2(1);
        return texelFetch(tex, clamp(p, ivec2(0), hi), 0);
}

// Emulation of textureGather(tex, coord, MODE):
//   x = (i0, j0+1), y = (i0+1, j0+1), z = (i0+1, j0), w = (i0, j0)
vec4 gather_c(vec2 coord)
{
        ivec2 b = ivec2(floor(coord * u_src_size - 0.5));
        return vec4(fetch4(b + ivec2(0, 1))[MODE],
                    fetch4(b + ivec2(1, 1))[MODE],
                    fetch4(b + ivec2(1, 0))[MODE],
                    fetch4(b)[MODE]);
}

vec3 sample_bilinear(vec2 uv)
{
        vec2 t = uv * u_src_size - 0.5;
        ivec2 i0 = ivec2(floor(t));
        vec2 fr = t - vec2(i0);
        vec3 a = fetch4(i0).rgb;
        vec3 b = fetch4(i0 + ivec2(1, 0)).rgb;
        vec3 c = fetch4(i0 + ivec2(0, 1)).rgb;
        vec3 d = fetch4(i0 + ivec2(1, 1)).rgb;
        return mix(mix(a, b, fr.x), mix(c, d, fr.x), fr.y);
}

float fastLanczos2(float x)
{
        float wA = x - 4.0;
        float wB = x * wA - wA;
        wA *= wA;
        return wB * wA;
}

vec2 weightY(float dx, float dy, float c, float std)
{
        float x = ((dx * dx) + (dy * dy)) * 0.55 + clamp(abs(c) * std, 0.0, 1.0);
        float w = fastLanczos2(x);
        return vec2(w, w * c);
}

void main()
{
        vec2 vp_inv = 1.0 / u_src_size;     // ViewportInfo.xy
        vec2 uv = tex_coord;

        vec4 color;
        color.xyz = sample_bilinear(uv);

        vec2 imgCoord = (uv * u_src_size) + vec2(-0.5, 0.5);
        vec2 imgCoordPixel = floor(imgCoord);
        vec2 coord = imgCoordPixel * vp_inv;
        vec2 pl = imgCoord + (-imgCoordPixel);
        vec4 left = gather_c(coord);

        float edgeVote = abs(left.z - left.y) + abs(color[MODE] - left.y)
                       + abs(color[MODE] - left.z);
        if (edgeVote > u_edge_threshold) {
                coord.x += vp_inv.x;

                vec4 right = gather_c(coord + vec2(vp_inv.x, 0.0));
                vec4 upDown;
                upDown.xy = gather_c(coord + vec2(0.0, -vp_inv.y)).wz;
                upDown.zw = gather_c(coord + vec2(0.0,  vp_inv.y)).yx;

                float mean = (left.y + left.z + right.x + right.w) * 0.25;
                left = left - vec4(mean);
                right = right - vec4(mean);
                upDown = upDown - vec4(mean);
                color.w = color[MODE] - mean;

                float sum = (((((abs(left.x) + abs(left.y)) + abs(left.z)) + abs(left.w))
                            + (((abs(right.x) + abs(right.y)) + abs(right.z)) + abs(right.w)))
                            + (((abs(upDown.x) + abs(upDown.y)) + abs(upDown.z)) + abs(upDown.w)));
                float std = 2.181818 / max(sum, 1.0e-6);

                vec2 aWY = weightY(pl.x,       pl.y + 1.0, upDown.x, std);
                aWY += weightY(pl.x - 1.0, pl.y + 1.0, upDown.y, std);
                aWY += weightY(pl.x - 1.0, pl.y - 2.0, upDown.z, std);
                aWY += weightY(pl.x,       pl.y - 2.0, upDown.w, std);
                aWY += weightY(pl.x + 1.0, pl.y - 1.0, left.x,   std);
                aWY += weightY(pl.x,       pl.y - 1.0, left.y,   std);
                aWY += weightY(pl.x,       pl.y,       left.z,   std);
                aWY += weightY(pl.x + 1.0, pl.y,       left.w,   std);
                aWY += weightY(pl.x - 1.0, pl.y - 1.0, right.x,  std);
                aWY += weightY(pl.x - 2.0, pl.y - 1.0, right.y,  std);
                aWY += weightY(pl.x - 2.0, pl.y,       right.z,  std);
                aWY += weightY(pl.x - 1.0, pl.y,       right.w,  std);

                float finalY = aWY.y / aWY.x;

                float maxY = max(max(left.y, left.z), max(right.x, right.w));
                float minY = min(min(left.y, left.z), min(right.x, right.w));
                finalY = clamp(u_edge_sharpness * finalY, minY, maxY);

                float deltaY = finalY - color.w;

                // smooth high contrast input
                deltaY = clamp(deltaY, -23.0 / 255.0, 23.0 / 255.0);

                color.x = clamp(color.x + deltaY, 0.0, 1.0);
                color.y = clamp(color.y + deltaY, 0.0, 1.0);
                color.z = clamp(color.z + deltaY, 0.0, 1.0);
        }

        frag_color = vec4(color.xyz, 1.0);
}
