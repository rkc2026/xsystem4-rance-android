/* AMD FidelityFX Super Resolution 1.0 -- RCAS (Robust Contrast Adaptive Sharpening)
 *
 * GLSL ES 3.00 port of the float (non-packed) RCAS path from ffx_fsr1.h
 * (FidelityFX-FSR v1.20210629).
 *
 *   Copyright (c) 2021 Advanced Micro Devices, Inc. All rights reserved.
 *   Distributed under the MIT License, see licenses/FidelityFX-FSR.txt.
 *
 * Changes from the reference implementation:
 *  - The divisions that the reference leaves to hardware NaN semantics of
 *    min()/max() (0*inf on black or white neighbourhoods) are guarded so the
 *    result is well defined on every GPU.
 *  - The optional denoise path is not included.
 */

uniform highp sampler2D tex;
uniform vec2 u_src_size;    // size of the input texture (== render target)
uniform float u_sharpness;  // linear sharpness: exp2(-stops), 1.0 = maximum

in vec2 tex_coord;
out vec4 frag_color;

// This is set at the limit of providing unnatural results for sharpening.
const float FSR_RCAS_LIMIT = 0.25 - (1.0 / 16.0);

vec3 load_rgb(ivec2 p)
{
        ivec2 hi = ivec2(u_src_size) - ivec2(1);
        return texelFetch(tex, clamp(p, ivec2(0), hi), 0).rgb;
}

void main()
{
        // Algorithm uses minimal 3x3 pixel neighborhood.
        //    b
        //  d e f
        //    h
        ivec2 sp = ivec2(floor(tex_coord * u_src_size));
        vec3 b = load_rgb(sp + ivec2( 0, -1));
        vec3 d = load_rgb(sp + ivec2(-1,  0));
        vec3 e = load_rgb(sp);
        vec3 f = load_rgb(sp + ivec2( 1,  0));
        vec3 h = load_rgb(sp + ivec2( 0,  1));

        // Min and max of ring.
        vec3 mn4 = min(min(min(b, d), f), h);
        vec3 mx4 = max(max(max(b, d), f), h);

        // Limiters.
        vec3 hitMin = min(mn4, e) / max(4.0 * mx4, vec3(1.0e-6));
        vec3 hitMax = (1.0 - max(mx4, e)) / min(4.0 * mn4 - 4.0, vec3(-1.0e-6));
        vec3 lobeRGB = max(-hitMin, hitMax);
        float lobe = max(-FSR_RCAS_LIMIT,
                         min(max(lobeRGB.r, max(lobeRGB.g, lobeRGB.b)), 0.0))
                   * u_sharpness;

        // Resolve.
        float rcpL = 1.0 / (4.0 * lobe + 1.0);
        vec3 pix = (lobe * b + lobe * d + lobe * h + lobe * f + e) * rcpL;
        frag_color = vec4(pix, 1.0);
}
