/* Full-screen quad vertex shader for the FSR / SGSR upscaling passes.
 *
 * The unit quad [0,1]x[0,1] is mapped to the whole render target without any
 * flipping, so the output texture keeps the same orientation as its input.
 */

in vec4 vertex_pos;
in vec2 vertex_uv;
out vec2 tex_coord;

void main() {
        gl_Position = vec4(vertex_pos.xy * 2.0 - 1.0, 0.0, 1.0);
        tex_coord = vertex_uv;
}
