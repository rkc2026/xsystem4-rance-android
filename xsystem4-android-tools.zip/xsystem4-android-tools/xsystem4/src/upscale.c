/* Copyright (C) 2026 xsystem4-android contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://gnu.org/licenses/>.
 */

#include <math.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>

#include "gfx/gfx.h"
#include "gfx/private.h"
#include "system4.h"
#include "upscale.h"

/*
 * Quality modes.
 *
 * The game surface has a fixed logical resolution, so the "render scale" of
 * the usual FSR presets cannot be applied to the game itself. Instead the
 * quality mode selects the resolution the upscaler works at, as a fraction
 * of the screen viewport (never below the game's own resolution). The result
 * is stretched the rest of the way with bilinear filtering. Lower modes do
 * proportionally less work per frame; higher modes are closer to the screen's
 * native resolution and therefore sharper.
 *
 * Sharpening is the same in every mode, using the values recommended by the
 * upscalers' authors: FSR's RCAS at 0.2 stops, and SGSR's default edge
 * sharpness (2.0) and edge threshold (8/255). (Measured against a ground
 * truth image, varying these changes the result far less than the resolution
 * does.)
 */
struct preset {
	const char *name;
	float scale;
};

static const struct preset presets[NR_UPSCALE_QUALITIES] = {
	[UPSCALE_ULTRA_QUALITY] = { "Ultra Quality", 1.00f },
	[UPSCALE_QUALITY]       = { "Quality",       0.85f },
	[UPSCALE_BALANCED]      = { "Balanced",      0.70f },
	[UPSCALE_PERFORMANCE]   = { "Performance",   0.50f },
};

#define FSR_RCAS_STOPS     0.2f
#define SGSR_EDGE_SHARPNESS 2.0f
#define SGSR_EDGE_THRESHOLD (8.0f / 255.0f)

static const char *mode_names[NR_UPSCALE_MODES] = {
	[UPSCALE_OFF]  = "Off",
	[UPSCALE_FSR]  = "FSR 1.0",
	[UPSCALE_SGSR] = "SGSR 1.0",
};

static atomic_int cfg_mode = UPSCALE_OFF;
static atomic_int cfg_quality = UPSCALE_QUALITY;

void upscale_set(int mode, int quality)
{
	if (mode < 0 || mode >= NR_UPSCALE_MODES)
		mode = UPSCALE_OFF;
	if (quality < 0 || quality >= NR_UPSCALE_QUALITIES)
		quality = UPSCALE_QUALITY;
	atomic_store(&cfg_mode, mode);
	atomic_store(&cfg_quality, quality);
}

void upscale_get(int *mode, int *quality)
{
	if (mode)
		*mode = atomic_load(&cfg_mode);
	if (quality)
		*quality = atomic_load(&cfg_quality);
}

bool upscale_parse_mode(const char *s, int *mode)
{
	if (!strcasecmp(s, "off") || !strcasecmp(s, "none"))
		*mode = UPSCALE_OFF;
	else if (!strcasecmp(s, "fsr"))
		*mode = UPSCALE_FSR;
	else if (!strcasecmp(s, "sgsr"))
		*mode = UPSCALE_SGSR;
	else
		return false;
	return true;
}

bool upscale_parse_quality(const char *s, int *quality)
{
	if (!strcasecmp(s, "ultra") || !strcasecmp(s, "ultra-quality"))
		*quality = UPSCALE_ULTRA_QUALITY;
	else if (!strcasecmp(s, "quality"))
		*quality = UPSCALE_QUALITY;
	else if (!strcasecmp(s, "balanced"))
		*quality = UPSCALE_BALANCED;
	else if (!strcasecmp(s, "performance"))
		*quality = UPSCALE_PERFORMANCE;
	else
		return false;
	return true;
}

/* Status text, shown in the settings UI. */

static pthread_mutex_t status_lock = PTHREAD_MUTEX_INITIALIZER;
static char status_text[256] = "Off";

static void set_status(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void set_status(const char *fmt, ...)
{
	char tmp[sizeof(status_text)];
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(tmp, sizeof(tmp), fmt, ap);
	va_end(ap);
	pthread_mutex_lock(&status_lock);
	if (strcmp(tmp, status_text))
		memcpy(status_text, tmp, sizeof(status_text));
	pthread_mutex_unlock(&status_lock);
}

void upscale_status(char *buf, size_t size)
{
	pthread_mutex_lock(&status_lock);
	snprintf(buf, size, "%s", status_text);
	pthread_mutex_unlock(&status_lock);
}

/* GL resources */

struct pass_shader {
	struct shader sh;
	const char *frag;
	bool tried;
	bool ok;
	char error[256];
	GLint u_src_size;
	GLint u_out_size;
	GLint u_sharpness;
	GLint u_edge_sharpness;
	GLint u_edge_threshold;
};

struct pass_params {
	struct pass_shader *ps;
	float src_w, src_h;
	float out_w, out_h;
	float sharpness;       // RCAS: linear
	float edge_sharpness;  // SGSR
	float edge_threshold;  // SGSR
};

static struct pass_shader easu_shader = { .frag = "shaders/fsr_easu.f.glsl" };
static struct pass_shader rcas_shader = { .frag = "shaders/fsr_rcas.f.glsl" };
static struct pass_shader sgsr_shader = { .frag = "shaders/sgsr.f.glsl" };

static void pass_prepare(struct gfx_render_job *job, void *data)
{
	struct pass_params *p = data;
	struct pass_shader *ps = p->ps;
	if (ps->u_src_size >= 0)
		glUniform2f(ps->u_src_size, p->src_w, p->src_h);
	if (ps->u_out_size >= 0)
		glUniform2f(ps->u_out_size, p->out_w, p->out_h);
	if (ps->u_sharpness >= 0)
		glUniform1f(ps->u_sharpness, p->sharpness);
	if (ps->u_edge_sharpness >= 0)
		glUniform1f(ps->u_edge_sharpness, p->edge_sharpness);
	if (ps->u_edge_threshold >= 0)
		glUniform1f(ps->u_edge_threshold, p->edge_threshold);
}

static bool shader_ready(struct pass_shader *ps)
{
	if (ps->tried)
		return ps->ok;
	ps->tried = true;
	if (!gfx_try_load_shader(&ps->sh, "shaders/upscale.v.glsl", ps->frag,
				 ps->error, sizeof(ps->error))) {
		WARNING("Upscaler shader %s unavailable: %s", ps->frag, ps->error);
		return false;
	}
	ps->sh.prepare = pass_prepare;
	GLuint prog = ps->sh.program;
	ps->u_src_size = glGetUniformLocation(prog, "u_src_size");
	ps->u_out_size = glGetUniformLocation(prog, "u_out_size");
	ps->u_sharpness = glGetUniformLocation(prog, "u_sharpness");
	ps->u_edge_sharpness = glGetUniformLocation(prog, "u_edge_sharpness");
	ps->u_edge_threshold = glGetUniformLocation(prog, "u_edge_threshold");
	ps->ok = true;
	return true;
}

struct target {
	GLuint tex;
	GLuint fbo;
	int w, h;
};

static struct target targets[2];
static bool targets_failed = false;

static bool ensure_target(struct target *t, int w, int h)
{
	if (t->tex && t->w == w && t->h == h)
		return true;
	if (!t->tex) {
		glGenTextures(1, &t->tex);
		glGenFramebuffers(1, &t->fbo);
	}
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, t->tex);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glBindFramebuffer(GL_FRAMEBUFFER, t->fbo);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t->tex, 0);
	t->w = w;
	t->h = h;
	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
		glDeleteFramebuffers(1, &t->fbo);
		glDeleteTextures(1, &t->tex);
		memset(t, 0, sizeof(*t));
		return false;
	}
	return true;
}

static void release_targets(void)
{
	for (int i = 0; i < 2; i++) {
		if (targets[i].tex) {
			glDeleteFramebuffers(1, &targets[i].fbo);
			glDeleteTextures(1, &targets[i].tex);
		}
		memset(&targets[i], 0, sizeof(targets[i]));
	}
}

static const GLfloat identity[16] = {
	1, 0, 0, 0,
	0, 1, 0, 0,
	0, 0, 1, 0,
	0, 0, 0, 1,
};

static void run_pass(struct pass_shader *ps, GLuint src_tex, int src_w, int src_h,
		     struct target *dst)
{
	struct pass_params params = {
		.ps = ps,
		.src_w = src_w,
		.src_h = src_h,
		.out_w = dst->w,
		.out_h = dst->h,
		.sharpness = exp2f(-FSR_RCAS_STOPS),
		.edge_sharpness = SGSR_EDGE_SHARPNESS,
		.edge_threshold = SGSR_EDGE_THRESHOLD,
	};
	struct gfx_render_job job = {
		.shader = &ps->sh,
		.shape = GFX_RECTANGLE,
		.texture = src_tex,
		.world_transform = (GLfloat *)identity,
		.view_transform = (GLfloat *)identity,
		.data = &params,
	};
	glBindFramebuffer(GL_FRAMEBUFFER, dst->fbo);
	glViewport(0, 0, dst->w, dst->h);
	gfx_render(&job);
}

GLuint upscale_process(struct texture *src, int vp_w, int vp_h)
{
	int mode = atomic_load(&cfg_mode);
	int quality = atomic_load(&cfg_quality);

	if (mode == UPSCALE_OFF) {
		set_status("Off");
		return 0;
	}
	if (!src || !src->handle || src->w <= 0 || src->h <= 0 || vp_w <= 0 || vp_h <= 0)
		return 0;
	if (quality < 0 || quality >= NR_UPSCALE_QUALITIES)
		quality = UPSCALE_QUALITY;
	const struct preset *pr = &presets[quality];

	// Resolution the upscaler runs at: a fraction of the screen viewport,
	// but never below the game's own resolution.
	int tw = (int)(vp_w * pr->scale + 0.5f);
	int th = (int)(vp_h * pr->scale + 0.5f);
	if (tw < src->w)
		tw = src->w;
	if (th < src->h)
		th = src->h;
	if (tw > vp_w)
		tw = vp_w;
	if (th > vp_h)
		th = vp_h;

	if (tw < src->w || th < src->h || (vp_w == src->w && vp_h == src->h)) {
		set_status("%s: inactive (screen %dx%d is not larger than the game %dx%d)",
			   mode_names[mode], vp_w, vp_h, src->w, src->h);
		return 0;
	}

	struct pass_shader *first = mode == UPSCALE_FSR ? &easu_shader : &sgsr_shader;
	bool use_rcas = mode == UPSCALE_FSR;
	if (!shader_ready(first) || (use_rcas && !shader_ready(&rcas_shader))) {
		struct pass_shader *bad = !first->ok ? first : &rcas_shader;
		set_status("%s unavailable: %s", mode_names[mode], bad->error);
		return 0;
	}

	if (targets_failed ||
	    !ensure_target(&targets[0], tw, th) ||
	    (use_rcas && !ensure_target(&targets[1], tw, th))) {
		if (!targets_failed)
			WARNING("Upscaler: failed to create render targets (%dx%d)", tw, th);
		targets_failed = true;
		release_targets();
		set_status("%s unavailable: cannot create %dx%d render target", mode_names[mode], tw, th);
		return 0;
	}

	GLboolean blend = glIsEnabled(GL_BLEND);
	glDisable(GL_BLEND);

	run_pass(first, src->handle, src->w, src->h, &targets[0]);
	GLuint result = targets[0].tex;
	if (use_rcas) {
		run_pass(&rcas_shader, targets[0].tex, tw, th, &targets[1]);
		result = targets[1].tex;
	}

	if (blend)
		glEnable(GL_BLEND);

	set_status("%s, %s: %dx%d -> %dx%d (screen %dx%d)", mode_names[mode], pr->name,
		   src->w, src->h, tw, th, vp_w, vp_h);
	return result;
}
