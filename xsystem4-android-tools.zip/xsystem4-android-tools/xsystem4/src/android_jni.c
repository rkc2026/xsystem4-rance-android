/* Copyright (C) 2026 xsystem4-android contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://gnu.org/licenses/>.
 */

/*
 * JNI bridge between the Android UI (io.github.kichikuou.xsystem4.NativeBridge)
 * and the engine's upscaler and cheat engine. These functions are called on
 * the Android UI thread, not on the game thread.
 */

#if defined(__ANDROID__) || defined(XSYS4_JNI)

#include <jni.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cheat.h"
#include "upscale.h"

#define JNI_FN(name) Java_io_github_kichikuou_xsystem4_NativeBridge_##name
#define RESULT_BUFFER_SIZE (256 * 1024)

/*
 * NewStringUTF() expects "modified UTF-8", which differs from UTF-8 for
 * characters outside the BMP. Names in game data never need those, so
 * replace anything outside well-formed 1-3 byte sequences.
 */
static void sanitize_utf8(char *s)
{
	unsigned char *p = (unsigned char *)s;
	while (*p) {
		int n = 0;
		if (*p < 0x80)
			n = 1;
		else if ((*p & 0xe0) == 0xc0 && *p >= 0xc2)
			n = 2;
		else if ((*p & 0xf0) == 0xe0)
			n = 3;
		int ok = n > 0;
		for (int i = 1; ok && i < n; i++)
			ok = (p[i] & 0xc0) == 0x80;
		if (ok && n == 3) {
			unsigned cp = ((p[0] & 0x0f) << 12) | ((p[1] & 0x3f) << 6) | (p[2] & 0x3f);
			ok = cp >= 0x800 && !(cp >= 0xd800 && cp <= 0xdfff);
		}
		if (ok) {
			p += n;
		} else {
			*p++ = '?';
			// swallow continuation bytes of the broken sequence
			while ((*p & 0xc0) == 0x80)
				*p++ = '?';
		}
	}
}

static jstring make_jstring(JNIEnv *env, char *utf8)
{
	sanitize_utf8(utf8);
	return (*env)->NewStringUTF(env, utf8);
}

static char *copy_jstring(JNIEnv *env, jstring js)
{
	if (!js)
		return strdup("");
	const char *s = (*env)->GetStringUTFChars(env, js, NULL);
	if (!s)
		return strdup("");
	char *copy = strdup(s);
	(*env)->ReleaseStringUTFChars(env, js, s);
	return copy ? copy : strdup("");
}

// Returns the listing, or "!<code>" if the cheat engine reported an error.
static jstring listing_result(JNIEnv *env, char *buf, int rc)
{
	if (rc < 0) {
		char err[16];
		snprintf(err, sizeof(err), "!%d", rc);
		free(buf);
		return (*env)->NewStringUTF(env, err);
	}
	jstring js = make_jstring(env, buf);
	free(buf);
	return js;
}

JNIEXPORT void JNICALL JNI_FN(setUpscale)(JNIEnv *env, jclass cls, jint mode, jint quality)
{
	upscale_set(mode, quality);
}

JNIEXPORT jstring JNICALL JNI_FN(upscaleStatus)(JNIEnv *env, jclass cls)
{
	char buf[256];
	upscale_status(buf, sizeof(buf));
	return make_jstring(env, buf);
}

JNIEXPORT jint JNICALL JNI_FN(cheatReady)(JNIEnv *env, jclass cls)
{
	return cheat_is_ready() ? CHEAT_OK : CHEAT_NOT_READY;
}

JNIEXPORT jint JNICALL JNI_FN(cheatScanFirst)(JNIEnv *env, jclass cls, jint type, jint cmp,
					      jstring value, jint flags)
{
	char *v = copy_jstring(env, value);
	int rc = cheat_scan_first(type, cmp, v, flags);
	free(v);
	return rc;
}

JNIEXPORT jint JNICALL JNI_FN(cheatScanNext)(JNIEnv *env, jclass cls, jint cmp, jstring value)
{
	char *v = copy_jstring(env, value);
	int rc = cheat_scan_next(cmp, v);
	free(v);
	return rc;
}

JNIEXPORT void JNICALL JNI_FN(cheatScanReset)(JNIEnv *env, jclass cls)
{
	cheat_scan_reset();
}

JNIEXPORT jboolean JNICALL JNI_FN(cheatScanTruncated)(JNIEnv *env, jclass cls)
{
	return cheat_scan_truncated();
}

JNIEXPORT jstring JNICALL JNI_FN(cheatScanResults)(JNIEnv *env, jclass cls, jint offset, jint limit)
{
	char *buf = malloc(RESULT_BUFFER_SIZE);
	if (!buf)
		return (*env)->NewStringUTF(env, "");
	int rc = cheat_scan_results(offset, limit, buf, RESULT_BUFFER_SIZE);
	return listing_result(env, buf, rc);
}

JNIEXPORT jstring JNICALL JNI_FN(cheatBrowse)(JNIEnv *env, jclass cls, jstring filter, jint limit)
{
	char *buf = malloc(RESULT_BUFFER_SIZE);
	if (!buf)
		return (*env)->NewStringUTF(env, "");
	char *f = copy_jstring(env, filter);
	int rc = cheat_browse(f, limit, buf, RESULT_BUFFER_SIZE);
	free(f);
	return listing_result(env, buf, rc);
}

JNIEXPORT jstring JNICALL JNI_FN(cheatFrozen)(JNIEnv *env, jclass cls)
{
	char *buf = malloc(RESULT_BUFFER_SIZE);
	if (!buf)
		return (*env)->NewStringUTF(env, "");
	int rc = cheat_frozen_list(buf, RESULT_BUFFER_SIZE);
	return listing_result(env, buf, rc);
}

JNIEXPORT jint JNICALL JNI_FN(cheatWrite)(JNIEnv *env, jclass cls, jint slot, jint index,
					  jlong seq, jint kind, jstring value)
{
	char *v = copy_jstring(env, value);
	int rc = cheat_write(slot, index, (uint32_t)seq, kind, v);
	free(v);
	return rc;
}

JNIEXPORT jint JNICALL JNI_FN(cheatFreeze)(JNIEnv *env, jclass cls, jint slot, jint index,
					   jlong seq, jint kind, jstring value, jstring label,
					   jboolean enable)
{
	char *v = copy_jstring(env, value);
	char *l = copy_jstring(env, label);
	int rc = cheat_freeze(slot, index, (uint32_t)seq, kind, v, l, enable);
	free(v);
	free(l);
	return rc;
}

#endif /* __ANDROID__ || XSYS4_JNI */
