/* Copyright (C) 2026 xsystem4-android contributors
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see <http://gnu.org/licenses/>.
 */

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <math.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "system4/ain.h"
#include "system4/utfsjis.h"
#include "cheat.h"
#include "vm.h"
#include "vm/heap.h"
#include "vm/page.h"

/*
 * Variables are addressed by (heap slot, index in page, slot sequence number).
 * The sequence number changes whenever a heap slot is reused, so an address
 * left over from before a page was freed is detected as stale instead of
 * silently pointing at an unrelated object.
 */

#define MAX_CANDIDATES 3000000
#define MAX_FROZEN 128
#define LOCK_TIMEOUT_SEC 2

/* ------------------------------------------------------------------------ */
/* Hand-over of the VM between the game thread and the UI thread            */
/* ------------------------------------------------------------------------ */

static pthread_mutex_t vm_lock = PTHREAD_MUTEX_INITIALIZER;
static atomic_int ui_waiting;
static atomic_bool ready;
static bool inited;  // game thread only

static void apply_frozen(void);

void cheat_init(void)
{
	if (inited)
		return;
	inited = true;
	// The game thread owns the VM except while it sits at a safe point.
	pthread_mutex_lock(&vm_lock);
	atomic_store(&ready, true);
}

void cheat_safepoint_begin(void)
{
	if (!inited)
		return;
	apply_frozen();
	pthread_mutex_unlock(&vm_lock);
	// Give a waiting UI request a chance to take the lock before the game
	// thread re-acquires it (mutexes are not fair).
	for (int i = 0; i < 40 && atomic_load(&ui_waiting) > 0; i++)
		usleep(500);
}

void cheat_safepoint_end(void)
{
	if (inited)
		pthread_mutex_lock(&vm_lock);
}

bool cheat_is_ready(void)
{
	return atomic_load(&ready);
}

static int ui_lock(void)
{
	if (!atomic_load(&ready))
		return CHEAT_NOT_READY;
	atomic_fetch_add(&ui_waiting, 1);
	struct timespec ts;
	clock_gettime(CLOCK_REALTIME, &ts);
	ts.tv_sec += LOCK_TIMEOUT_SEC;
	int r = pthread_mutex_timedlock(&vm_lock, &ts);
	atomic_fetch_sub(&ui_waiting, 1);
	return r == 0 ? CHEAT_OK : CHEAT_BUSY;
}

static void ui_unlock(void)
{
	pthread_mutex_unlock(&vm_lock);
}

/* ------------------------------------------------------------------------ */
/* Variables                                                                 */
/* ------------------------------------------------------------------------ */

static bool is_container_type(enum ain_data_type t)
{
	switch (t) {
	case AIN_STRUCT:
	case AIN_ARRAY_INT:
	case AIN_ARRAY_FLOAT:
	case AIN_ARRAY_STRING:
	case AIN_ARRAY_STRUCT:
	case AIN_ARRAY_BOOL:
	case AIN_ARRAY_LONG_INT:
	case AIN_ARRAY_FUNC_TYPE:
	case AIN_ARRAY_DELEGATE:
	case AIN_ARRAY:
		return true;
	default:
		return false;
	}
}

// variable_type() with bounds checks, so that a stale or odd page can't make
// the cheat engine read outside of the AIN tables.
static enum ain_data_type safe_var_type(struct page *p, int i)
{
	if (i < 0 || i >= p->nr_vars)
		return AIN_VOID;
	switch (p->type) {
	case GLOBAL_PAGE:
		if (i >= ain->nr_globals)
			return AIN_VOID;
		break;
	case LOCAL_PAGE:
		if (p->index < 0 || p->index >= ain->nr_functions || i >= ain->functions[p->index].nr_vars)
			return AIN_VOID;
		break;
	case STRUCT_PAGE:
		if (p->index < 0 || p->index >= ain->nr_structures || i >= ain->structures[p->index].nr_members)
			return AIN_VOID;
		break;
	case ARRAY_PAGE:
		break;
	default:
		return AIN_VOID;
	}
	return variable_type(p, i, NULL, NULL);
}

static int scalar_kind(struct page *p, int i)
{
	switch (safe_var_type(p, i)) {
	case AIN_INT:
	case AIN_LONG_INT:
		return CHEAT_INT;
	case AIN_BOOL:
		return CHEAT_BOOL;
	case AIN_FLOAT:
		return CHEAT_FLOAT;
	default:
		return -1;
	}
}

static const char *raw_var_name(struct page *p, int i)
{
	switch (p->type) {
	case GLOBAL_PAGE:
		return i >= 0 && i < ain->nr_globals ? ain->globals[i].name : NULL;
	case LOCAL_PAGE:
		if (p->index >= 0 && p->index < ain->nr_functions && i >= 0 && i < ain->functions[p->index].nr_vars)
			return ain->functions[p->index].vars[i].name;
		return NULL;
	case STRUCT_PAGE:
		if (p->index >= 0 && p->index < ain->nr_structures && i >= 0 && i < ain->structures[p->index].nr_members)
			return ain->structures[p->index].members[i].name;
		return NULL;
	default:
		return NULL;
	}
}

static struct page *resolve(int32_t slot, int32_t index, uint32_t seq)
{
	if (slot < 0 || !page_index_valid(slot))
		return NULL;
	if (heap[slot].seq != seq)
		return NULL;
	struct page *p = heap[slot].page;
	if (!p || p->type == DELEGATE_PAGE || index < 0 || index >= p->nr_vars)
		return NULL;
	return p;
}

/* Replace anything that would break the tab/newline separated protocol. */
static void clean_text(char *s)
{
	for (; *s; s++) {
		if (*s == '\t' || *s == '\n' || *s == '\r')
			*s = ' ';
	}
}

static char *name_utf8(const char *raw)
{
	if (!raw || !*raw)
		return strdup("?");
	char *s = sjis2utf(raw, 0);
	if (!s)
		return strdup("?");
	clean_text(s);
	return s;
}

static void format_value(char *out, size_t size, int kind, union vm_value v)
{
	if (kind == CHEAT_FLOAT)
		snprintf(out, size, "%.7g", (double)v.f);
	else
		snprintf(out, size, "%d", v.i);
}

static bool parse_int(const char *s, int32_t *out)
{
	if (!s)
		return false;
	while (isspace((unsigned char)*s))
		s++;
	if (!*s)
		return false;
	const char *digits = s + (*s == '-' || *s == '+');
	int base = (digits[0] == '0' && (digits[1] == 'x' || digits[1] == 'X')) ? 16 : 10;
	char *end;
	errno = 0;
	long long v = strtoll(s, &end, base);
	if (end == s || errno)
		return false;
	while (isspace((unsigned char)*end))
		end++;
	if (*end)
		return false;
	if (v < INT32_MIN || v > (long long)UINT32_MAX)
		return false;
	*out = (int32_t)(uint32_t)(int64_t)v;
	return true;
}

static bool parse_float(const char *s, float *out)
{
	if (!s)
		return false;
	while (isspace((unsigned char)*s))
		s++;
	if (!*s)
		return false;
	char *end;
	errno = 0;
	float v = strtof(s, &end);
	if (end == s)
		return false;
	while (isspace((unsigned char)*end))
		end++;
	if (*end || !isfinite(v))
		return false;
	*out = v;
	return true;
}

static bool parse_value(int kind, const char *s, union vm_value *out)
{
	switch (kind) {
	case CHEAT_FLOAT: {
		float f;
		if (!parse_float(s, &f))
			return false;
		*out = vm_float(f);
		return true;
	}
	case CHEAT_BOOL: {
		int32_t i;
		if (!parse_int(s, &i))
			return false;
		*out = vm_int(i != 0);
		return true;
	}
	default: {
		int32_t i;
		if (!parse_int(s, &i))
			return false;
		*out = vm_int(i);
		return true;
	}
	}
}

/* ------------------------------------------------------------------------ */
/* Frozen values                                                             */
/* ------------------------------------------------------------------------ */

struct frozen {
	int32_t slot;
	int32_t index;
	uint32_t seq;
	int kind;
	union vm_value value;
	char label[96];
};

static struct frozen frozen[MAX_FROZEN];
static int nr_frozen;

static struct frozen *find_frozen(int32_t slot, int32_t index, uint32_t seq)
{
	for (int i = 0; i < nr_frozen; i++) {
		if (frozen[i].slot == slot && frozen[i].index == index && frozen[i].seq == seq)
			return &frozen[i];
	}
	return NULL;
}

// Called by the game thread (VM lock held) at every safe point.
static void apply_frozen(void)
{
	for (int i = 0; i < nr_frozen; ) {
		struct frozen *f = &frozen[i];
		struct page *p = resolve(f->slot, f->index, f->seq);
		if (!p || scalar_kind(p, f->index) < 0) {
			// The variable is gone (e.g. a different save was loaded).
			frozen[i] = frozen[--nr_frozen];
			continue;
		}
		if (p->values[f->index].i != f->value.i)
			p->values[f->index] = f->value;
		i++;
	}
}

/* ------------------------------------------------------------------------ */
/* Walking the variable tree (globals -> structs -> arrays)                 */
/* ------------------------------------------------------------------------ */

#define WALK_MAX_DEPTH 8
#define WALK_MAX_PAGES 400000

struct path_elem {
	const char *raw_name;  // SJIS/GBK name from the AIN, or NULL
	int index;             // array index when raw_name is NULL
};

struct walker {
	uint8_t *visited;
	int pages_left;
	int depth;
	struct path_elem stack[WALK_MAX_DEPTH + 1];
	void *ctx;
	bool (*on_page)(struct walker *, struct page *, int slot);  // false: stop
};

static void append(char *out, size_t size, const char *s)
{
	size_t len = strlen(out);
	if (len + 1 < size)
		snprintf(out + len, size - len, "%s", s);
}

// Append one path element ("name" / ".name" / "[i]") to OUT.
static void append_elem(char *out, size_t size, const char *raw_name, int index)
{
	if (raw_name) {
		char *n = name_utf8(raw_name);
		if (out[0])
			append(out, size, ".");
		append(out, size, n);
		free(n);
	} else {
		char tmp[24];
		snprintf(tmp, sizeof(tmp), "[%d]", index);
		append(out, size, tmp);
	}
}

static void path_format(const struct walker *w, char *out, size_t size)
{
	out[0] = '\0';
	for (int i = 0; i < w->depth; i++)
		append_elem(out, size, w->stack[i].raw_name, w->stack[i].index);
}

static bool walk_page(struct walker *w, int slot)
{
	if (w->pages_left <= 0)
		return false;
	if (slot < 0 || (size_t)slot >= heap_size || w->visited[slot >> 3] & (1u << (slot & 7)))
		return true;
	if (!page_index_valid(slot))
		return true;
	w->visited[slot >> 3] |= 1u << (slot & 7);
	w->pages_left--;

	struct page *p = heap[slot].page;
	if (p->type == DELEGATE_PAGE || p->type == LOCAL_PAGE)
		return true;
	if (!w->on_page(w, p, slot))
		return false;
	if (w->depth >= WALK_MAX_DEPTH || p->nr_vars <= 0)
		return true;

	bool is_array = p->type == ARRAY_PAGE;
	enum ain_data_type elem_type = is_array ? safe_var_type(p, 0) : AIN_VOID;
	if (is_array && !is_container_type(elem_type))
		return true;  // array of scalars/strings: no children

	for (int i = 0; i < p->nr_vars; i++) {
		if (!is_array && !is_container_type(safe_var_type(p, i)))
			continue;
		int child = p->values[i].i;
		if (child <= 0)
			continue;
		w->stack[w->depth++] = (struct path_elem) {
			.raw_name = is_array ? NULL : raw_var_name(p, i),
			.index = i,
		};
		bool cont = walk_page(w, child);
		w->depth--;
		if (!cont)
			return false;
	}
	return true;
}

static void walk_globals(void *ctx, bool (*on_page)(struct walker *, struct page *, int))
{
	struct walker w = {
		.visited = calloc(heap_size / 8 + 1, 1),
		.pages_left = WALK_MAX_PAGES,
		.ctx = ctx,
		.on_page = on_page,
	};
	if (!w.visited)
		return;
	if (heap_size > 0 && heap[0].ref > 0)
		walk_page(&w, 0);
	free(w.visited);
}

// Label of element I of page P, given the path BASE of the page itself.
static void element_label(struct page *p, int slot, int i, const char *base, char *out, size_t size)
{
	snprintf(out, size, "%s", base);
	switch (p->type) {
	case ARRAY_PAGE:
		append_elem(out, size, NULL, i);
		break;
	case GLOBAL_PAGE:
	case STRUCT_PAGE:
		append_elem(out, size, raw_var_name(p, i), i);
		break;
	default:
		break;
	}
	(void)slot;
}

// Fallback label for pages that can't be reached from the globals.
static void fallback_label(struct page *p, int slot, int i, char *out, size_t size)
{
	char tmp[160];
	const char *raw = raw_var_name(p, i);
	char *n = raw ? name_utf8(raw) : NULL;
	switch (p->type) {
	case STRUCT_PAGE: {
		const char *sname = (p->index >= 0 && p->index < ain->nr_structures) ? ain->structures[p->index].name : NULL;
		char *s = name_utf8(sname);
		snprintf(tmp, sizeof(tmp), "%s.%s @%d", s, n ? n : "?", slot);
		free(s);
		break;
	}
	case LOCAL_PAGE: {
		const char *fname = (p->index >= 0 && p->index < ain->nr_functions) ? ain->functions[p->index].name : NULL;
		char *f = name_utf8(fname);
		snprintf(tmp, sizeof(tmp), "%s() / %s", f, n ? n : "?");
		free(f);
		break;
	}
	case ARRAY_PAGE:
		snprintf(tmp, sizeof(tmp), "array @%d [%d]", slot, i);
		break;
	default:
		snprintf(tmp, sizeof(tmp), "%s", n ? n : "?");
		break;
	}
	free(n);
	snprintf(out, size, "%s", tmp);
}

/* ------------------------------------------------------------------------ */
/* Output buffer helper                                                      */
/* ------------------------------------------------------------------------ */

struct outbuf {
	char *buf;
	size_t size;
	size_t len;
	bool full;
};

static void out_line(struct outbuf *o, int32_t slot, int32_t index, uint32_t seq, int kind,
		     bool is_frozen, union vm_value v, const char *label)
{
	if (o->full)
		return;
	char val[40];
	format_value(val, sizeof(val), kind, v);
	char lab[200];
	snprintf(lab, sizeof(lab), "%s", label);
	clean_text(lab);
	int n = snprintf(o->buf + o->len, o->size - o->len, "%d\t%d\t%u\t%d\t%d\t%s\t%s\n",
			 slot, index, seq, kind, is_frozen ? 1 : 0, val, lab);
	if (n < 0 || (size_t)n >= o->size - o->len) {
		o->full = true;
		o->buf[o->len] = '\0';
		return;
	}
	o->len += n;
}

/* ------------------------------------------------------------------------ */
/* Variable browser                                                          */
/* ------------------------------------------------------------------------ */

static bool contains_icase(const char *hay, const char *needle)
{
	if (!*needle)
		return true;
	size_t nl = strlen(needle);
	for (; *hay; hay++) {
		size_t i = 0;
		while (i < nl && hay[i] &&
		       tolower((unsigned char)hay[i]) == tolower((unsigned char)needle[i]))
			i++;
		if (i == nl)
			return true;
	}
	return false;
}

struct browse_ctx {
	const char *filter;
	int limit;
	int emitted;
	struct outbuf *out;
};

static bool browse_on_page(struct walker *w, struct page *p, int slot)
{
	struct browse_ctx *c = w->ctx;
	char base[512];
	bool have_base = false;
	int seen = 0;

	for (int i = 0; i < p->nr_vars; i++) {
		int kind = scalar_kind(p, i);
		if (kind < 0)
			continue;
		if (p->type == ARRAY_PAGE && seen++ >= 128)
			break;  // only the first elements of big arrays are listed
		if (!have_base) {
			path_format(w, base, sizeof(base));
			have_base = true;
		}
		char label[640];
		element_label(p, slot, i, base, label, sizeof(label));
		if (c->filter[0] && !contains_icase(label, c->filter))
			continue;
		out_line(c->out, slot, i, heap[slot].seq, kind,
			 find_frozen(slot, i, heap[slot].seq) != NULL, p->values[i], label);
		if (c->out->full || ++c->emitted >= c->limit)
			return false;
	}
	return true;
}

int cheat_browse(const char *filter, int limit, char *buf, size_t size)
{
	int rc = ui_lock();
	if (rc)
		return rc;
	struct outbuf out = { .buf = buf, .size = size };
	buf[0] = '\0';
	struct browse_ctx ctx = { .filter = filter ? filter : "", .limit = limit > 0 ? limit : 200, .out = &out };
	walk_globals(&ctx, browse_on_page);
	ui_unlock();
	return (int)out.len;
}

/* ------------------------------------------------------------------------ */
/* Scanner                                                                   */
/* ------------------------------------------------------------------------ */

struct candidate {
	int32_t slot;
	int32_t index;
	uint32_t seq;
	union vm_value prev;
};

static struct candidate *cands;
static size_t nr_cands;
static size_t cap_cands;
static int scan_type = -1;  // -1: no scan in progress
static atomic_bool scan_truncated;

static void free_scan(void)
{
	free(cands);
	cands = NULL;
	nr_cands = cap_cands = 0;
	scan_type = -1;
	atomic_store(&scan_truncated, false);
}

static bool add_candidate(int32_t slot, int32_t index, uint32_t seq, union vm_value v)
{
	if (nr_cands >= MAX_CANDIDATES) {
		atomic_store(&scan_truncated, true);
		return false;
	}
	if (nr_cands == cap_cands) {
		size_t ncap = cap_cands ? cap_cands * 2 : 4096;
		struct candidate *n = realloc(cands, ncap * sizeof(*n));
		if (!n) {
			atomic_store(&scan_truncated, true);
			return false;
		}
		cands = n;
		cap_cands = ncap;
	}
	cands[nr_cands++] = (struct candidate) { slot, index, seq, v };
	return true;
}

static bool float_eq(float a, float b)
{
	return fabsf(a - b) <= 1e-4f * fmaxf(1.0f, fabsf(b));
}

static bool match_value(int type, int cmp, union vm_value cur, union vm_value prev, union vm_value arg)
{
	if (type == CHEAT_SCAN_FLOAT) {
		if (!isfinite(cur.f))
			return false;
		switch (cmp) {
		case CHEAT_CMP_EXACT:     return float_eq(cur.f, arg.f);
		case CHEAT_CMP_UNKNOWN:   return true;
		case CHEAT_CMP_GREATER:   return cur.f > arg.f;
		case CHEAT_CMP_LESS:      return cur.f < arg.f;
		case CHEAT_CMP_CHANGED:   return cur.i != prev.i;
		case CHEAT_CMP_UNCHANGED: return cur.i == prev.i;
		case CHEAT_CMP_INCREASED: return cur.f > prev.f;
		case CHEAT_CMP_DECREASED: return cur.f < prev.f;
		}
	} else {
		switch (cmp) {
		case CHEAT_CMP_EXACT:     return cur.i == arg.i;
		case CHEAT_CMP_UNKNOWN:   return true;
		case CHEAT_CMP_GREATER:   return cur.i > arg.i;
		case CHEAT_CMP_LESS:      return cur.i < arg.i;
		case CHEAT_CMP_CHANGED:   return cur.i != prev.i;
		case CHEAT_CMP_UNCHANGED: return cur.i == prev.i;
		case CHEAT_CMP_INCREASED: return cur.i > prev.i;
		case CHEAT_CMP_DECREASED: return cur.i < prev.i;
		}
	}
	return false;
}

static bool cmp_needs_value(int cmp)
{
	return cmp == CHEAT_CMP_EXACT || cmp == CHEAT_CMP_GREATER || cmp == CHEAT_CMP_LESS;
}

static bool kind_matches_type(int kind, int type)
{
	if (type == CHEAT_SCAN_FLOAT)
		return kind == CHEAT_FLOAT;
	return kind == CHEAT_INT || kind == CHEAT_BOOL;
}

int cheat_scan_first(int type, int cmp, const char *value, int flags)
{
	if (type != CHEAT_SCAN_INT && type != CHEAT_SCAN_FLOAT)
		return CHEAT_BAD_TYPE;
	if (cmp != CHEAT_CMP_EXACT && cmp != CHEAT_CMP_UNKNOWN &&
	    cmp != CHEAT_CMP_GREATER && cmp != CHEAT_CMP_LESS)
		return CHEAT_BAD_TYPE;

	union vm_value arg = { .i = 0 };
	if (cmp_needs_value(cmp) && !parse_value(type == CHEAT_SCAN_FLOAT ? CHEAT_FLOAT : CHEAT_INT, value, &arg))
		return CHEAT_BAD_VALUE;

	int rc = ui_lock();
	if (rc)
		return rc;

	free_scan();
	scan_type = type;
	for (size_t s = 0; s < heap_size; s++) {
		if (!page_index_valid(s))
			continue;
		struct page *p = heap[s].page;
		if (p->type == DELEGATE_PAGE)
			continue;
		if (p->type == LOCAL_PAGE && !(flags & CHEAT_SCAN_INCLUDE_LOCALS))
			continue;
		uint32_t seq = heap[s].seq;

		// Arrays have a single element type; avoid asking for each element.
		int array_kind = -1;
		if (p->type == ARRAY_PAGE) {
			if (p->nr_vars <= 0)
				continue;
			array_kind = scalar_kind(p, 0);
			if (array_kind < 0 || !kind_matches_type(array_kind, type))
				continue;
		}
		for (int i = 0; i < p->nr_vars; i++) {
			int kind = p->type == ARRAY_PAGE ? array_kind : scalar_kind(p, i);
			if (kind < 0 || !kind_matches_type(kind, type))
				continue;
			union vm_value v = p->values[i];
			if (!match_value(type, cmp, v, v, arg))
				continue;
			if (!add_candidate(s, i, seq, v))
				goto done;
		}
	}
done:;
	int n = (int)nr_cands;
	ui_unlock();
	return n;
}

int cheat_scan_next(int cmp, const char *value)
{
	if (cmp < CHEAT_CMP_EXACT || cmp > CHEAT_CMP_DECREASED || cmp == CHEAT_CMP_UNKNOWN)
		return CHEAT_BAD_TYPE;
	union vm_value arg = { .i = 0 };
	// scan_type is only written under the lock, but reading the type needed
	// to parse the value requires it; parse after locking.
	int rc = ui_lock();
	if (rc)
		return rc;
	if (scan_type < 0) {
		ui_unlock();
		return CHEAT_NO_SCAN;
	}
	if (cmp_needs_value(cmp) &&
	    !parse_value(scan_type == CHEAT_SCAN_FLOAT ? CHEAT_FLOAT : CHEAT_INT, value, &arg)) {
		ui_unlock();
		return CHEAT_BAD_VALUE;
	}

	size_t keep = 0;
	for (size_t i = 0; i < nr_cands; i++) {
		struct candidate *c = &cands[i];
		struct page *p = resolve(c->slot, c->index, c->seq);
		if (!p)
			continue;
		union vm_value cur = p->values[c->index];
		if (!match_value(scan_type, cmp, cur, c->prev, arg))
			continue;
		cands[keep] = *c;
		cands[keep].prev = cur;
		keep++;
	}
	nr_cands = keep;
	int n = (int)nr_cands;
	ui_unlock();
	return n;
}

void cheat_scan_reset(void)
{
	if (ui_lock() != CHEAT_OK)
		return;
	free_scan();
	ui_unlock();
}

bool cheat_scan_truncated(void)
{
	return atomic_load(&scan_truncated);
}

struct label_ctx {
	int32_t *wanted;  // sorted, unique heap slots
	char **paths;     // path of each wanted slot (NULL: unreachable)
	int nr_wanted;
	int found;
};

static int cmp_i32(const void *a, const void *b)
{
	int32_t x = *(const int32_t *)a, y = *(const int32_t *)b;
	return (x > y) - (x < y);
}

static bool label_on_page(struct walker *w, struct page *p, int slot)
{
	struct label_ctx *c = w->ctx;
	int32_t key = slot;
	int32_t *hit = bsearch(&key, c->wanted, c->nr_wanted, sizeof(int32_t), cmp_i32);
	if (hit) {
		int k = hit - c->wanted;
		if (!c->paths[k]) {
			char path[512];
			path_format(w, path, sizeof(path));
			c->paths[k] = strdup(path);
			c->found++;
		}
	}
	(void)p;
	return c->found < c->nr_wanted;
}

int cheat_scan_results(int offset, int limit, char *buf, size_t size)
{
	int rc = ui_lock();
	if (rc)
		return rc;
	buf[0] = '\0';
	struct outbuf out = { .buf = buf, .size = size };
	if (scan_type < 0) {
		ui_unlock();
		return CHEAT_NO_SCAN;
	}
	if (offset < 0)
		offset = 0;
	if (limit <= 0)
		limit = 100;
	size_t end = (size_t)offset + limit;
	if (end > nr_cands)
		end = nr_cands;

	// Find readable names for the pages the shown results live in.
	struct label_ctx lc = { 0 };
	if ((size_t)offset < end) {
		size_t n = end - offset;
		lc.wanted = malloc(n * sizeof(int32_t));
		lc.paths = calloc(n, sizeof(char *));
		if (lc.wanted && lc.paths) {
			for (size_t i = offset; i < end; i++)
				lc.wanted[lc.nr_wanted++] = cands[i].slot;
			qsort(lc.wanted, lc.nr_wanted, sizeof(int32_t), cmp_i32);
			int u = 0;
			for (int i = 0; i < lc.nr_wanted; i++) {
				if (i == 0 || lc.wanted[i] != lc.wanted[i - 1])
					lc.wanted[u++] = lc.wanted[i];
			}
			lc.nr_wanted = u;
			walk_globals(&lc, label_on_page);
		}
	}

	for (size_t i = offset; i < end; i++) {
		struct candidate *c = &cands[i];
		struct page *p = resolve(c->slot, c->index, c->seq);
		if (!p)
			continue;  // went away since the last scan
		int kind = scalar_kind(p, c->index);
		if (kind < 0)
			continue;
		char label[640];
		int32_t key = c->slot;
		int32_t *hit = lc.nr_wanted ? bsearch(&key, lc.wanted, lc.nr_wanted, sizeof(int32_t), cmp_i32) : NULL;
		if (hit && lc.paths[hit - lc.wanted])
			element_label(p, c->slot, c->index, lc.paths[hit - lc.wanted], label, sizeof(label));
		else
			fallback_label(p, c->slot, c->index, label, sizeof(label));
		out_line(&out, c->slot, c->index, c->seq, kind,
			 find_frozen(c->slot, c->index, c->seq) != NULL, p->values[c->index], label);
	}

	if (lc.paths) {
		for (int i = 0; i < lc.nr_wanted; i++)
			free(lc.paths[i]);
	}
	free(lc.paths);
	free(lc.wanted);
	ui_unlock();
	return (int)out.len;
}

/* ------------------------------------------------------------------------ */
/* Editing                                                                   */
/* ------------------------------------------------------------------------ */

int cheat_write(int32_t slot, int32_t index, uint32_t seq, int kind_hint, const char *value)
{
	(void)kind_hint;
	int rc = ui_lock();
	if (rc)
		return rc;
	struct page *p = resolve(slot, index, seq);
	if (!p) {
		ui_unlock();
		return CHEAT_STALE;
	}
	int kind = scalar_kind(p, index);
	union vm_value v;
	if (kind < 0) {
		ui_unlock();
		return CHEAT_BAD_TYPE;
	}
	if (!parse_value(kind, value, &v)) {
		ui_unlock();
		return CHEAT_BAD_VALUE;
	}
	p->values[index] = v;
	// Keep a frozen entry in sync, otherwise the next safe point would undo
	// the edit.
	struct frozen *f = find_frozen(slot, index, seq);
	if (f)
		f->value = v;
	ui_unlock();
	return CHEAT_OK;
}

int cheat_freeze(int32_t slot, int32_t index, uint32_t seq, int kind_hint, const char *value,
		 const char *label, bool enable)
{
	(void)kind_hint;
	int rc = ui_lock();
	if (rc)
		return rc;
	struct frozen *f = find_frozen(slot, index, seq);
	if (!enable) {
		if (f)
			*f = frozen[--nr_frozen];
		ui_unlock();
		return CHEAT_OK;
	}

	struct page *p = resolve(slot, index, seq);
	if (!p) {
		ui_unlock();
		return CHEAT_STALE;
	}
	int kind = scalar_kind(p, index);
	if (kind < 0) {
		ui_unlock();
		return CHEAT_BAD_TYPE;
	}
	union vm_value v;
	if (value && *value) {
		if (!parse_value(kind, value, &v)) {
			ui_unlock();
			return CHEAT_BAD_VALUE;
		}
	} else {
		v = p->values[index];  // freeze at the current value
	}
	if (!f) {
		if (nr_frozen >= MAX_FROZEN) {
			ui_unlock();
			return CHEAT_FULL;
		}
		f = &frozen[nr_frozen++];
		f->slot = slot;
		f->index = index;
		f->seq = seq;
	}
	f->kind = kind;
	f->value = v;
	snprintf(f->label, sizeof(f->label), "%s", label ? label : "");
	clean_text(f->label);
	p->values[index] = v;
	ui_unlock();
	return CHEAT_OK;
}

int cheat_frozen_list(char *buf, size_t size)
{
	int rc = ui_lock();
	if (rc)
		return rc;
	buf[0] = '\0';
	struct outbuf out = { .buf = buf, .size = size };
	for (int i = 0; i < nr_frozen; i++) {
		struct frozen *f = &frozen[i];
		struct page *p = resolve(f->slot, f->index, f->seq);
		if (!p)
			continue;
		out_line(&out, f->slot, f->index, f->seq, f->kind, true, p->values[f->index], f->label);
	}
	ui_unlock();
	return (int)out.len;
}

/* ------------------------------------------------------------------------ */
/* VM restart                                                                */
/* ------------------------------------------------------------------------ */

// Game thread, VM lock held.
void cheat_vm_reset(void)
{
	free_scan();
	nr_frozen = 0;
}
