package io.github.kichikuou.xsystem4

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.RelativeLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * In-game tools: a small floating button that opens a panel with
 *  - Graphics: FSR / SGSR upscaling and quality mode
 *  - Scan:     a cheat-engine style memory scanner for the game's variables
 *  - Variables: a browser for the game's named variables
 *  - Frozen:   values that are being held fixed
 *
 * The game keeps running while the panel is open.
 */
class ToolsPanel(private val activity: Activity, private val settings: GraphicsSettings) {
    companion object {
        private const val RESULT_LIMIT = 100
        private const val BROWSE_LIMIT = 300
    }

    private class Entry(
        val slot: Int,
        val index: Int,
        val seq: Long,
        val kind: Int,
        val frozen: Boolean,
        val value: String,
        val label: String,
    ) {
        override fun toString() = label
    }

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val density = activity.resources.displayMetrics.density
    private var dialog: Dialog? = null

    // State of the scanner (the engine keeps the candidate list itself).
    private var scanActive = false

    private fun dp(v: Int) = (v * density + 0.5f).toInt()

    // ------------------------------------------------------------------------------------
    // Floating button
    // ------------------------------------------------------------------------------------

    fun attachButton(parent: ViewGroup) {
        val size = dp(40)
        val button = TextView(activity).apply {
            text = "\u2699"  // gear
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            alpha = 0.45f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x99000000.toInt())
            }
            contentDescription = "Game tools"
        }
        val lp: ViewGroup.LayoutParams = if (parent is RelativeLayout) {
            RelativeLayout.LayoutParams(size, size).apply {
                addRule(RelativeLayout.ALIGN_PARENT_TOP)
                addRule(RelativeLayout.ALIGN_PARENT_RIGHT)
                setMargins(0, dp(8), dp(8), 0)
            }
        } else {
            FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(8), dp(8), 0)
            }
        }
        parent.addView(button, lp)

        // Tap opens the panel; dragging moves the button out of the way.
        val slop = ViewConfiguration.get(activity).scaledTouchSlop
        button.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startTx = 0f
            private var startTy = 0f
            private var dragging = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startTx = v.translationX
                        startTy = v.translationY
                        dragging = false
                        v.alpha = 0.9f
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            v.translationX = (startTx + dx).coerceIn(-v.left.toFloat(), (parent.width - v.right).toFloat())
                            v.translationY = (startTy + dy).coerceIn(-v.top.toFloat(), (parent.height - v.bottom).toFloat())
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        v.alpha = 0.45f
                        if (!dragging) show()
                    }
                    MotionEvent.ACTION_CANCEL -> v.alpha = 0.45f
                }
                return true
            }
        })
    }

    // ------------------------------------------------------------------------------------
    // Panel
    // ------------------------------------------------------------------------------------

    fun show() {
        if (dialog?.isShowing == true) return
        val d = Dialog(activity, android.R.style.Theme_Material_Dialog_NoActionBar)
        dialog = d

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(0xF2202124.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }

        val content = FrameLayout(activity)
        val tabRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val tabs = listOf<Pair<String, () -> View>>(
            "Graphics" to { buildGraphics() },
            "Scan" to { buildScan() },
            "Variables" to { buildVariables() },
            "Frozen" to { buildFrozen() },
        )
        val tabButtons = ArrayList<Button>()
        fun select(i: Int) {
            content.removeAllViews()
            content.addView(tabs[i].second())
            tabButtons.forEachIndexed { j, b -> b.alpha = if (j == i) 1f else 0.55f; b.setTypeface(null, if (j == i) Typeface.BOLD else Typeface.NORMAL) }
        }
        tabs.forEachIndexed { i, (title, _) ->
            val b = Button(activity).apply {
                text = title
                isAllCaps = false
                textSize = 13f
                minWidth = 0
                minimumWidth = 0
                setOnClickListener { select(i) }
            }
            tabButtons.add(b)
            tabRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(tabRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(6) })
        val close = Button(activity).apply {
            text = "Close"
            isAllCaps = false
            setOnClickListener { d.dismiss() }
        }
        root.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        select(0)
        d.setContentView(root)
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.show()
        d.window?.let { w ->
            val m = activity.resources.displayMetrics
            val lp = WindowManager.LayoutParams().apply {
                copyFrom(w.attributes)
                width = (m.widthPixels * 0.94f).toInt().coerceAtMost(dp(640))
                height = (m.heightPixels * 0.92f).toInt()
            }
            w.attributes = lp
            w.setBackgroundDrawableResource(android.R.color.transparent)
        }
    }

    // ------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------

    private fun toast(msg: String) = Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()

    private fun text(s: String, size: Float = 14f, bold: Boolean = false, color: Int = Color.WHITE) =
        TextView(activity).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun vbox() = LinearLayout(activity).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(4), dp(4), dp(4), dp(4))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    /** Run [work] off the UI thread, then [done] on it. */
    private fun <T : Any> bg(work: () -> T, done: (T) -> Unit) {
        worker.execute {
            val result: T? = try {
                work()
            } catch (t: Throwable) {
                null
            }
            ui.post {
                if (result == null) toast("Game tools are not available in this build") else done(result)
            }
        }
    }

    private fun errorText(code: Int) = when (code) {
        NativeBridge.ERR_BUSY -> "The game is busy right now - try again"
        NativeBridge.ERR_NOT_READY -> "The game has not started yet"
        NativeBridge.ERR_STALE -> "That variable no longer exists - scan again"
        NativeBridge.ERR_BAD_VALUE -> "Invalid value"
        NativeBridge.ERR_BAD_TYPE -> "That variable can't be changed"
        NativeBridge.ERR_FULL -> "Too many frozen values (max 128)"
        NativeBridge.ERR_NO_SCAN -> "Do a first scan first"
        else -> "Error $code"
    }

    /** Parses engine listing output. Returns null (after reporting it) if the engine returned an error. */
    private fun parseEntries(text: String): List<Entry>? {
        if (text.startsWith("!")) {
            toast(errorText(text.substring(1).toIntOrNull() ?: 0))
            return null
        }
        return text.lineSequence().filter { it.isNotEmpty() }.mapNotNull { line ->
            val p = line.split('\t', limit = 7)
            if (p.size < 7) return@mapNotNull null
            try {
                Entry(p[0].toInt(), p[1].toInt(), p[2].toLong(), p[3].toInt(), p[4] == "1", p[5], p[6])
            } catch (e: NumberFormatException) {
                null
            }
        }.toList()
    }

    private fun entryAdapter(items: MutableList<Entry>) =
        object : ArrayAdapter<Entry>(activity, android.R.layout.simple_list_item_2, android.R.id.text1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                val e = items[position]
                v.findViewById<TextView>(android.R.id.text1).apply {
                    text = e.label
                    textSize = 14f
                    setTextColor(Color.WHITE)
                }
                v.findViewById<TextView>(android.R.id.text2).apply {
                    text = (if (e.frozen) "\u2744 " else "") + e.value + (if (e.kind == NativeBridge.SCAN_FLOAT) "   (float)" else "")
                    textSize = 13f
                    setTextColor(if (e.frozen) 0xFF8AB4F8.toInt() else 0xFFBDC1C6.toInt())
                }
                return v
            }
        }

    private fun numberInput(initial: String = "", hint: String = "") = EditText(activity).apply {
        setText(initial)
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine()
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF9AA0A6.toInt())
    }

    /** Dialog for changing, freezing or unfreezing one variable. */
    private fun editEntry(e: Entry, reload: () -> Unit) {
        val input = numberInput(e.value)
        input.setSelectAllOnFocus(true)
        val builder = AlertDialog.Builder(activity, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(e.label)
            .setMessage("Current value: ${e.value}" + if (e.frozen) "  (frozen)" else "")
            .setView(input)
            .setPositiveButton("Set") { _, _ ->
                val v = input.text.toString()
                bg({ NativeBridge.cheatWrite(e.slot, e.index, e.seq, e.kind, v) }) { rc ->
                    if (rc != NativeBridge.OK) toast(errorText(rc))
                    reload()
                }
            }
            .setNegativeButton("Cancel", null)
        if (e.frozen) {
            builder.setNeutralButton("Unfreeze") { _, _ ->
                bg({ NativeBridge.cheatFreeze(e.slot, e.index, e.seq, e.kind, "", e.label, false) }) { rc ->
                    if (rc != NativeBridge.OK) toast(errorText(rc))
                    reload()
                }
            }
        } else {
            builder.setNeutralButton("Freeze") { _, _ ->
                val v = input.text.toString()
                bg({ NativeBridge.cheatFreeze(e.slot, e.index, e.seq, e.kind, v, e.label, true) }) { rc ->
                    if (rc != NativeBridge.OK) toast(errorText(rc))
                    reload()
                }
            }
        }
        builder.show()
    }

    // ------------------------------------------------------------------------------------
    // Graphics tab
    // ------------------------------------------------------------------------------------

    private fun applyUpscale(status: TextView) {
        bg({
            NativeBridge.setUpscale(settings.mode, settings.quality)
            Thread.sleep(350)  // the status text is updated when the next frame is drawn
            NativeBridge.upscaleStatus()
        }) { status.text = it }
    }

    private fun buildGraphics(): View {
        val box = vbox()
        val status = text("", 12f, color = 0xFF8AB4F8.toInt()).apply { typeface = Typeface.MONOSPACE }

        box.addView(text("Upscaler", 16f, bold = true))
        val modes = listOf(
            "Off  (the game's normal smooth stretch)",
            "FSR 1.0  (AMD FidelityFX Super Resolution)",
            "SGSR 1.0  (Snapdragon Game Super Resolution)",
        )
        val modeGroup = RadioGroup(activity).apply { orientation = RadioGroup.VERTICAL }
        modes.forEachIndexed { i, name ->
            val rb = RadioButton(activity).apply {
                text = name
                id = View.generateViewId()
                tag = i
                setTextColor(Color.WHITE)
            }
            modeGroup.addView(rb)
            if (i == settings.mode) rb.isChecked = true
        }
        box.addView(modeGroup, matchWrap())

        box.addView(text("Quality mode", 16f, bold = true).apply { setPadding(0, dp(10), 0, 0) })
        val qualities = listOf(
            "Ultra Quality  -  works at 100% of the screen resolution",
            "Quality  -  85%",
            "Balanced  -  70%",
            "Performance  -  50%  (lightest on the GPU)",
        )
        val qualityGroup = RadioGroup(activity).apply { orientation = RadioGroup.VERTICAL }
        qualities.forEachIndexed { i, name ->
            val rb = RadioButton(activity).apply {
                text = name
                id = View.generateViewId()
                tag = i
                setTextColor(Color.WHITE)
            }
            qualityGroup.addView(rb)
            if (i == settings.quality) rb.isChecked = true
        }
        box.addView(qualityGroup, matchWrap())

        modeGroup.setOnCheckedChangeListener { g, id ->
            val i = g.findViewById<View>(id)?.tag as? Int ?: return@setOnCheckedChangeListener
            settings.mode = i
            applyUpscale(status)
        }
        qualityGroup.setOnCheckedChangeListener { g, id ->
            val i = g.findViewById<View>(id)?.tag as? Int ?: return@setOnCheckedChangeListener
            settings.quality = i
            applyUpscale(status)
        }

        box.addView(status, matchWrap().apply { topMargin = dp(10) })
        box.addView(
            text(
                "The upscaler sharpens the picture when the game is shown larger than its own " +
                    "resolution. The quality mode sets the resolution the filter works at, as a " +
                    "share of your screen: higher is sharper, lower is lighter on the GPU. " +
                    "Changes apply immediately and are remembered.",
                12f, color = 0xFFBDC1C6.toInt(),
            ).apply { setPadding(0, dp(8), 0, 0) }
        )
        applyUpscale(status)

        val scroll = android.widget.ScrollView(activity)
        scroll.addView(box)
        return scroll
    }

    // ------------------------------------------------------------------------------------
    // Scan tab
    // ------------------------------------------------------------------------------------

    private fun buildScan(): View {
        val box = vbox()
        val results = ArrayList<Entry>()
        val adapter = entryAdapter(results)
        val summary = text("", 13f, color = 0xFF8AB4F8.toInt())

        val typeSpinner = Spinner(activity).apply {
            // `this.adapter`: a bare `adapter` would refer to the results adapter above.
            this.adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_item, listOf("Whole number (int)", "Decimal (float)"))
                .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            isEnabled = !scanActive
        }
        val firstCmds = listOf("Exact value" to NativeBridge.CMP_EXACT, "Unknown initial value" to NativeBridge.CMP_UNKNOWN,
            "Greater than" to NativeBridge.CMP_GREATER, "Less than" to NativeBridge.CMP_LESS)
        val nextCmds = listOf("Exact value" to NativeBridge.CMP_EXACT, "Changed" to NativeBridge.CMP_CHANGED,
            "Unchanged" to NativeBridge.CMP_UNCHANGED, "Increased" to NativeBridge.CMP_INCREASED,
            "Decreased" to NativeBridge.CMP_DECREASED, "Greater than" to NativeBridge.CMP_GREATER,
            "Less than" to NativeBridge.CMP_LESS)
        val cmpSpinner = Spinner(activity)
        val input = numberInput(hint = "Value")
        val scanButton = Button(activity).apply { isAllCaps = false }
        val resetButton = Button(activity).apply { text = "Reset"; isAllCaps = false }
        val refreshButton = Button(activity).apply { text = "Refresh"; isAllCaps = false }
        val locals = CheckBox(activity).apply {
            text = "Include local variables"
            setTextColor(Color.WHITE)
            isEnabled = !scanActive
        }
        val list = ListView(activity).apply { this.adapter = adapter }

        fun currentCmds() = if (scanActive) nextCmds else firstCmds
        fun refreshControls() {
            val cmds = currentCmds()
            cmpSpinner.adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_item, cmds.map { it.first })
                .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            scanButton.text = if (scanActive) "Next scan" else "First scan"
            typeSpinner.isEnabled = !scanActive
            locals.isEnabled = !scanActive
        }

        fun loadResults() {
            bg({ NativeBridge.cheatScanResults(0, RESULT_LIMIT) }) { listing ->
                val entries = parseEntries(listing) ?: return@bg
                results.clear()
                results.addAll(entries)
                adapter.notifyDataSetChanged()
            }
        }

        fun setBusy(busy: Boolean) {
            scanButton.isEnabled = !busy
            resetButton.isEnabled = !busy
            if (busy) summary.text = "Scanning..."
        }

        fun finishScan(count: Int) {
            setBusy(false)
            if (count < 0) {
                summary.text = errorText(count)
                return
            }
            scanActive = true
            refreshControls()
            summary.text = when {
                count == 0 -> "No matches. Reset and try again."
                count > RESULT_LIMIT -> "$count matches (showing the first $RESULT_LIMIT). Change the value in the game, then use Next scan."
                else -> "$count match" + (if (count == 1) "" else "es") + ". Tap one to change or freeze it."
            }
            if (NativeBridge.cheatScanTruncated()) summary.text = summary.text.toString() + "  [list was capped]"
            loadResults()
        }

        scanButton.setOnClickListener {
            val cmd = currentCmds()[cmpSpinner.selectedItemPosition].second
            val v = input.text.toString()
            setBusy(true)
            if (!scanActive) {
                val type = if (typeSpinner.selectedItemPosition == 1) NativeBridge.SCAN_FLOAT else NativeBridge.SCAN_INT
                val flags = if (locals.isChecked) NativeBridge.SCAN_INCLUDE_LOCALS else 0
                bg({ NativeBridge.cheatScanFirst(type, cmd, v, flags) }) { finishScan(it) }
            } else {
                bg({ NativeBridge.cheatScanNext(cmd, v) }) { finishScan(it) }
            }
        }
        resetButton.setOnClickListener {
            bg({ NativeBridge.cheatScanReset() }) {
                scanActive = false
                results.clear()
                adapter.notifyDataSetChanged()
                summary.text = "Enter a value (for example your current gold) and press First scan."
                refreshControls()
            }
        }
        refreshButton.setOnClickListener { if (scanActive) loadResults() }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            editEntry(results[pos]) { loadResults() }
        }

        val row1 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(typeSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row1.addView(cmpSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val row2 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f))
        row2.addView(scanButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val row3 = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(locals, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        row3.addView(refreshButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row3.addView(resetButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        box.addView(row1, matchWrap())
        box.addView(row2, matchWrap())
        box.addView(row3, matchWrap())
        box.addView(summary, matchWrap().apply { topMargin = dp(4); bottomMargin = dp(4) })
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        summary.text = if (scanActive) "Scan in progress." else "Enter a value (for example your current gold) and press First scan."
        refreshControls()
        if (scanActive) loadResults()
        return box
    }

    // ------------------------------------------------------------------------------------
    // Variables tab
    // ------------------------------------------------------------------------------------

    private fun buildVariables(): View {
        val box = vbox()
        val items = ArrayList<Entry>()
        val adapter = entryAdapter(items)
        val summary = text("", 13f, color = 0xFF8AB4F8.toInt())
        val filter = EditText(activity).apply {
            hint = "Name filter (e.g. gold, hp)"
            setSingleLine()
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9AA0A6.toInt())
        }
        val search = Button(activity).apply { text = "Search"; isAllCaps = false }
        val list = ListView(activity).apply { this.adapter = adapter }

        fun load() {
            summary.text = "Searching..."
            val f = filter.text.toString()
            bg({ NativeBridge.cheatBrowse(f, BROWSE_LIMIT) }) { listing ->
                val entries = parseEntries(listing)
                if (entries == null) {
                    summary.text = ""
                    return@bg
                }
                items.clear()
                items.addAll(entries)
                adapter.notifyDataSetChanged()
                summary.text = when {
                    entries.isEmpty() -> "No variables match."
                    entries.size >= BROWSE_LIMIT -> "Showing the first $BROWSE_LIMIT variables - narrow the filter."
                    else -> "${entries.size} variables. Tap one to change or freeze it."
                }
            }
        }
        search.setOnClickListener { load() }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> editEntry(items[pos]) { load() } }

        val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(filter, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        row.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(row, matchWrap())
        box.addView(summary, matchWrap().apply { topMargin = dp(4); bottomMargin = dp(4) })
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        load()
        return box
    }

    // ------------------------------------------------------------------------------------
    // Frozen tab
    // ------------------------------------------------------------------------------------

    private fun buildFrozen(): View {
        val box = vbox()
        val items = ArrayList<Entry>()
        val adapter = entryAdapter(items)
        val summary = text("", 13f, color = 0xFF8AB4F8.toInt())
        val list = ListView(activity).apply { this.adapter = adapter }

        fun load() {
            bg({ NativeBridge.cheatFrozen() }) { listing ->
                val entries = parseEntries(listing) ?: return@bg
                items.clear()
                items.addAll(entries)
                adapter.notifyDataSetChanged()
                summary.text = if (entries.isEmpty())
                    "Nothing is frozen. Freeze a value from the Scan or Variables tab to keep it from changing."
                else
                    "${entries.size} frozen. Tap one to change or release it."
            }
        }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ -> editEntry(items[pos]) { load() } }
        box.addView(summary, matchWrap().apply { bottomMargin = dp(4) })
        box.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        load()
        return box
    }
}
