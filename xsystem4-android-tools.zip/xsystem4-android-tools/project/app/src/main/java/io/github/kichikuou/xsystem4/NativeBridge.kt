package io.github.kichikuou.xsystem4

/**
 * JNI bridge to the engine (xsystem4/src/android_jni.c). Only usable in the game process, after
 * SDL has loaded libxsystem4.so. All calls may be made from the UI thread; the ones that touch
 * the game's VM wait (up to ~2 s) for the game thread to reach a safe point and report
 * [ERR_BUSY] if it doesn't.
 */
object NativeBridge {
    const val OK = 0
    const val ERR_BUSY = -1
    const val ERR_NOT_READY = -2
    const val ERR_STALE = -3
    const val ERR_BAD_VALUE = -4
    const val ERR_BAD_TYPE = -5
    const val ERR_FULL = -6
    const val ERR_NO_SCAN = -7

    // Value types for a scan (enum cheat_scan_type)
    const val SCAN_INT = 0
    const val SCAN_FLOAT = 1

    // Comparisons (enum cheat_cmp)
    const val CMP_EXACT = 0
    const val CMP_UNKNOWN = 1
    const val CMP_GREATER = 2
    const val CMP_LESS = 3
    const val CMP_CHANGED = 4
    const val CMP_UNCHANGED = 5
    const val CMP_INCREASED = 6
    const val CMP_DECREASED = 7

    const val SCAN_INCLUDE_LOCALS = 1

    // Upscaler
    @JvmStatic external fun setUpscale(mode: Int, quality: Int)
    @JvmStatic external fun upscaleStatus(): String

    // Cheat engine
    @JvmStatic external fun cheatReady(): Int
    @JvmStatic external fun cheatScanFirst(type: Int, cmp: Int, value: String, flags: Int): Int
    @JvmStatic external fun cheatScanNext(cmp: Int, value: String): Int
    @JvmStatic external fun cheatScanReset()
    @JvmStatic external fun cheatScanTruncated(): Boolean

    // The following return tab-separated lines "slot index seq kind frozen value label", or
    // "!<code>" when the engine reported an error.
    @JvmStatic external fun cheatScanResults(offset: Int, limit: Int): String
    @JvmStatic external fun cheatBrowse(filter: String, limit: Int): String
    @JvmStatic external fun cheatFrozen(): String

    @JvmStatic external fun cheatWrite(slot: Int, index: Int, seq: Long, kind: Int, value: String): Int
    @JvmStatic external fun cheatFreeze(
        slot: Int, index: Int, seq: Long, kind: Int, value: String, label: String, enable: Boolean
    ): Int
}
