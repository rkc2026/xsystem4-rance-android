package io.github.kichikuou.xsystem4

import android.annotation.TargetApi
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

interface GameListObserver {
    fun onInstallProgress(path: String)
    fun onInstallSuccess()
    fun onInstallFailure(msgId: Int)
}

sealed class InstallState {
    object Idle : InstallState()
    data class Installing(val progress: String?) : InstallState()
    object Succeeded : InstallState()
    data class Failed(val msgId: Int) : InstallState()
}

data class Item(val name: String, val path: File, val homedir: File, val savedir: File?, val icon: File?, val error: String?, val encoding: String = "sjis") {
    companion object {
        fun fromDirectory(dir: File, homedir: File, context: Context): Item {
            var iniFile = File(dir, "System40.ini")
            if (!iniFile.exists())
                iniFile = File(dir, "AliceStart.ini")
            if (!iniFile.exists()) {
                val err = context.getString(R.string.toast_no_ini, dir.path)
                Log.w("GameList", err)
                return Item(dir.name, dir, homedir, null, null, err)
            }
            val icon = findIcon(dir)
            val ini = System40Ini.parse(iniFile, Xsys4rc.read(dir)["encoding"])
            if (ini.gameName == null) {
                val err = context.getString(R.string.toast_no_GameName, iniFile.path)
                Log.w("GameList", err)
                return Item(dir.name, dir, homedir, null, icon, err)
            }
            val savedir = File(dir, ini.SaveFolder ?: "SaveData")
            return Item(ini.gameName, dir, homedir, savedir, icon, null, ini.encoding)
        }

        private fun findIcon(dir: File): File? {
            dir.listFiles()?.forEach {
                if (it.extension == "ico") { return it }
            }
            try {
                dir.listFiles { file ->
                    file.extension == "exe" &&
                            file.name != "OpenSaveFolder.exe" &&
                            file.name != "ResetConfig.exe" &&
                            file.name != "Uninstaller.exe"
                }?.forEach { exeFile ->
                    PEResourceExtractor.create(exeFile)?.extractIcon()?.let { bytes ->
                        val f = File(dir, ".xsystem4.ico")
                        f.writeBytes(bytes)
                        return f
                    }
                }
            } catch (e: Exception) {
                Log.e("GameList", "Failed to extract or write icon", e)
            }
            return null
        }
    }

    fun getIconBitmap(reqSize: Int): Bitmap? {
        val bytes = icon?.readBytes() ?: return null
        val buf = ByteBuffer.wrap(bytes)
        buf.order(ByteOrder.LITTLE_ENDIAN)
        buf.skip(4)
        val numIcons = buf.short.toInt()

        // If the icon contains multiple images, convert it to an icon containing only the image
        // closest to the requested size.
        if (numIcons > 1) {
            val bestMatchEntry = Array(numIcons) {
                val entryBytes = ByteArray(16)
                buf.get(entryBytes)
                entryBytes
            }.minWith(compareBy({
                // Compare the sizes first,
                val width = if (it[0].toInt() == 0) 256 else it[0].toInt()
                kotlin.math.abs(width - reqSize)
            }, {
                // then pick the one with the highest number of bits per pixel.
                -it[6]
            }))
            buf.position(4)
            buf.putShort(1)
            buf.put(bestMatchEntry)
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
}

data class System40Ini(val gameName: String?, val SaveFolder: String?, val encoding: String) {
    companion object {
        // `encoding` is the value of the encoding setting in .xsys4rc. If it is not given, the
        // encoding is detected from the content of the file.
        fun parse(file: File, encoding: String?): System40Ini {
            val bytes = file.readBytes()
            val enc = encoding ?: detectEncoding(bytes)
            val charset = charsetOrNull(enc) ?: Charset.forName("Shift_JIS")
            val regex = Regex("""(\w+)\s*=\s*"(.*)"""")
            var gameName: String? = null
            var SaveFolder: String? = null
            for (line in String(bytes, charset).lines()) {
                regex.matchEntire(line)?.let {
                    when (it.groupValues[1]) {
                        "GameName" -> gameName = it.groupValues[2]
                        "SaveFolder" -> SaveFolder = it.groupValues[2]
                    }
                }
            }
            return System40Ini(gameName, SaveFolder, enc)
        }

        private fun charsetOrNull(name: String): Charset? =
            try {
                Charset.forName(name)
            } catch (e: IllegalArgumentException) {
                null
            }

        // Shift_JIS is tried first, because Shift_JIS text is often also valid GBK (as garbage),
        // but GBK text rarely is valid Shift_JIS.
        private fun detectEncoding(bytes: ByteArray): String =
            if (!canDecode(bytes, "Shift_JIS") && canDecode(bytes, "GBK")) "gbk" else "sjis"

        private fun canDecode(bytes: ByteArray, charsetName: String): Boolean {
            val decoder = Charset.forName(charsetName).newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            return try {
                decoder.decode(ByteBuffer.wrap(bytes))
                true
            } catch (e: CharacterCodingException) {
                false
            }
        }
    }
}

// Reads string settings (`name = "value"`) from the .xsys4rc file in a game directory.
object Xsys4rc {
    private val regex = Regex("""\s*([\w-]+)\s*=\s*"([^"]*)"\s*(?:(?:;|//).*)?""")

    fun read(gameDir: File): Map<String, String> {
        val file = File(gameDir, ".xsys4rc")
        if (!file.isFile) return emptyMap()
        // Setting names are ASCII; values and comments may use a legacy encoding.
        return file.useLines(Charsets.ISO_8859_1) { lines ->
            lines.mapNotNull { regex.matchEntire(it) }
                .associate { it.groupValues[1] to it.groupValues[2] }
        }
    }
}

class GameList(activity: Activity) {
    private val context: Context = activity.applicationContext
    private val items: ArrayList<Item> = arrayListOf()
    private val storageDirs: ArrayList<File> = arrayListOf()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var installJob: Job? = null
    operator fun get(index: Int): Item = items[index]
    val size: Int get() = items.size
    var observer: GameListObserver? = null
    var installState: InstallState = InstallState.Idle
        private set

    class InstallFailureException(val msgId: Int) : Exception()

    init {
        for (storagePath in activity.getExternalFilesDirs(null).filterNotNull()) {
            val state = Environment.getExternalStorageState(storagePath)
            Log.i("GameList", "${storagePath}: $state")
            if (state != Environment.MEDIA_MOUNTED && state != Environment.MEDIA_MOUNTED_READ_ONLY) {
                continue
            }
            storageDirs.add(storagePath)
            val homedir = File(storagePath, ".xsystem4")
            val files = storagePath.listFiles() ?: continue
            for (path in files) {
                if (!path.name.startsWith(".") && path.isDirectory) {
                    items.add(Item.fromDirectory(path, homedir, context))
                }
            }
            if (state == Environment.MEDIA_MOUNTED && files.isEmpty()) {
                // Create a dummy file and do a media scan so that `storagePath` is discoverable via MTP.
                // https://issuetracker.google.com/issues/37071807
                val dummyFile = File(storagePath, "dummy.txt")
                dummyFile.writeText("Create a subfolder here that stores game files.")
                MediaScannerConnection.scanFile(
                    activity,
                    arrayOf(dummyFile.absolutePath),
                    null,
                    null
                )
            }
        }
        moveSaveDirectories()
    }

    fun install(input: InputStream) {
        if (installJob?.isActive == true) {
            closeRejectedInput(input)
            return
        }
        installState = InstallState.Installing(null)
        installJob = scope.launch {
            try {
                input.use { installInput ->
                    val storagePath = storageDirs[0]
                    val path = withContext(Dispatchers.IO) {
                        doInstall(installInput, storagePath) { msg ->
                            withContext(Dispatchers.Main) {
                                setInstallProgress(msg)
                            }
                        }
                    }
                    val homedir = File(storagePath, ".xsystem4")
                    items.add(Item.fromDirectory(path, homedir, context))
                }
                setInstallSucceeded()
            } catch (e: InstallFailureException) {
                setInstallFailed(e.msgId)
            } catch (e: Exception) {
                Log.e("GameList", "Failed to extract ZIP", e)
                setInstallFailed(R.string.zip_extraction_error)
            }
        }
    }

    fun consumeInstallResult() {
        if (installState is InstallState.Succeeded || installState is InstallState.Failed) {
            installState = InstallState.Idle
        }
    }

    private fun setInstallProgress(progress: String) {
        installState = InstallState.Installing(progress)
        observer?.onInstallProgress(progress)
    }

    private fun setInstallSucceeded() {
        installState = InstallState.Succeeded
        observer?.onInstallSuccess()
    }

    private fun setInstallFailed(msgId: Int) {
        installState = InstallState.Failed(msgId)
        observer?.onInstallFailure(msgId)
    }

    private fun closeRejectedInput(input: InputStream) {
        try {
            input.close()
        } catch (e: IOException) {
            Log.w("GameList", "Failed to close rejected install input", e)
        }
    }

    @TargetApi(Build.VERSION_CODES.N)
    private suspend fun doInstall(
        input: InputStream,
        storagePath: File,
        progressCallback: suspend (String) -> Unit
    ): File {
        val tempDir = File(storagePath, ".install_temp")
        tempDir.deleteRecursively()
        val tempDirCanonical = tempDir.canonicalFile
        val zip = ZipInputStream(input.buffered(), Charset.forName("Shift_JIS"))
        var gameRoot: File? = null
        try {
            zip.use {
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.isDirectory) {
                        continue
                    }
                    val path = resolveZipEntryPath(tempDir, tempDirCanonical, entry.name)
                    Log.i("GameList", "Extracting ${entry.name}")
                    progressCallback(entry.name)
                    path.parentFile?.mkdirs()
                    path.outputStream().buffered().use { zip.copyTo(it) }

                    if (path.name == "System40.ini" || path.name == "AliceStart.ini") {
                        gameRoot = path.parentFile
                    }
                }
            }
            val srcDir = gameRoot ?: throw InstallFailureException(R.string.zip_no_ini)
            var dstDir = File(storagePath, srcDir.name)
            var i = 1
            while (dstDir.exists()) {
                dstDir = File(storagePath, "${srcDir.name} (${i++})")
            }
            if (!srcDir.renameTo(dstDir)) {
                throw IOException("Failed to move installed game: ${srcDir} -> ${dstDir}")
            }
            return dstDir
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private fun resolveZipEntryPath(tempDir: File, tempDirCanonical: File, entryName: String): File {
        val path = File(tempDir, entryName.replace('\\', File.separatorChar)).canonicalFile
        if (path == tempDirCanonical || !path.path.startsWith(tempDirCanonical.path + File.separator)) {
            throw IOException("ZIP entry escapes install directory: ${entryName}")
        }
        return path
    }

    fun uninstall(item: Item) {
        item.path.deleteRecursively()
        items.remove(item)
    }

    // Move save directories to the new location.
    // TODO: Remove this after some transition period.
    private fun moveSaveDirectories() {
        for (item in items) {
            if (item.error != null) continue
            val oldPath = File(item.homedir, item.name)
            val files = oldPath.listFiles() ?: continue
            for (file in files) {
                val newPath = File(item.path, file.name)
                Log.i("GameList", "Moving save directory: ${file} -> ${newPath}")
                if (newPath.exists()) {
                    Log.w("GameList", "Removing existing save directory: ${newPath}")
                    newPath.deleteRecursively()
                }
                file.renameTo(newPath)
            }
            oldPath.deleteRecursively()
        }
    }
}
