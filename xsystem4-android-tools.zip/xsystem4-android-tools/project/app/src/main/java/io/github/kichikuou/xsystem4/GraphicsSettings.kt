package io.github.kichikuou.xsystem4

import android.content.Context

/**
 * Upscaler settings. Used only in the game process, so plain SharedPreferences (which are not
 * multi-process safe) are fine.
 */
class GraphicsSettings(context: Context) {
    companion object {
        const val MODE_OFF = 0
        const val MODE_FSR = 1
        const val MODE_SGSR = 2

        const val QUALITY_ULTRA = 0
        const val QUALITY_QUALITY = 1
        const val QUALITY_BALANCED = 2
        const val QUALITY_PERFORMANCE = 3

        // Values of the engine's --upscale / --upscale-quality options, indexed by the constants above.
        val MODE_ARGS = arrayOf("off", "fsr", "sgsr")
        val QUALITY_ARGS = arrayOf("ultra", "quality", "balanced", "performance")
    }

    private val prefs = context.getSharedPreferences("graphics", Context.MODE_PRIVATE)

    var mode: Int
        get() = prefs.getInt("upscale_mode", MODE_OFF).coerceIn(0, MODE_ARGS.size - 1)
        set(value) { prefs.edit().putInt("upscale_mode", value).apply() }

    var quality: Int
        get() = prefs.getInt("upscale_quality", QUALITY_QUALITY).coerceIn(0, QUALITY_ARGS.size - 1)
        set(value) { prefs.edit().putInt("upscale_quality", value).apply() }
}
